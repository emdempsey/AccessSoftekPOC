﻿Configuration Bast {
        #AST modules resource
        Import-DscResource -ModuleName OrpheusDSC

        Import-DscResource -ModuleName xComputerManagement, xNetworking

        $DomainName = "devbeta.macuhosted"
        $UserName = "devbeta.macuhosted\nimda"
        $Password = "Office365" | ConvertTo-SecureString -asPlainText -Force #this is just for testing.
        $pass = New-Object System.Management.Automation.PSCredential ($UserName,$Password)
        Node Localhost {
           as_pFeatures DisFeature {
                        Ensure      = "Absent"
                        Features    = @("AD-Certificate",
                                "AD-Domain-Services",
                                "ADFS-Federation",
                                "ADLDS",
                                "ADRMS",
                                "AS-Dist-Transaction",
                                "DHCP",
                                "DNS",
                                "Fax",
                                "FS-BranchCache",
                                "FS-Data-Deduplication",
                                "FS-DFS-Namespace",
                                "FS-DFS-Replication",
                                "FS-Resource-Manager",
                                "FS-VSS-Agent",
                                "FS-iSCSITarget-Server",
                                "iSCSITarget-VSS-VDS",
                                "FS-NFS-Service",
                                "FS-SyncShareService",
                                "Hyper-V",
                                "NPAS",
                                "Print-Services",
                                "RemoteAccess",
                                "Remote-Desktop-Services",
                                "VolumeActivation",
                                "Web-DAV-Publishing",
                                "Web-Ftp-Server",
                                "Web-Mgmt-Compat",
                                "Web-Mgmt-Service",
                                "WDS",
                                "ServerEssentialsRole",
                                "UpdateServices",
                                "BITS",
                                "BitLocker",
                                "BitLocker-NetworkUnlock",
                                "BranchCache",
                                "NFS-Client",
                                "Data-Center-Bridging",
                                "Direct-Play",
                                "EnhancedStorage",
                                "Failover-Clustering",
                                "GPMC",
                                "Web-WHC",
                                "Internet-Print-Client",
                                "IPAM",
                                "ISNS",
                                "LPR-Port-Monitor",
                                "Multipath-IO",
                                "NLB",
                                "PNRP",
                                "qWave",
                                "CMAK",
                                "Remote-Assistance",
                                "RDC",
                                "RPC-over-HTTP-Proxy",
                                "Simple-TCPIP",
                                "FS-SMBBW",
                                "SMTP-Server",
                                "SNMP-Service",
                                "Telnet-Server",
                                "TFTP-Client",
                                "Biometric-Framework",
                                "WFF",
                                "Windows-Identity-Foundation",
                                "Windows-Internal-Database",
                                "Search-Service",
                                "Windows-Server-Backup",
                                "Migration",
                                "WindowsStorageManagementService",
                                "Windows-TIFF-IFilter",
                                "WinRM-IIS-Ext",
                                "Wireless-Networking")
            }
           as_pFeatures EnFeature {
                Ensure = "Absent"
                Features    = @("Telnet-Client",
                    "PowerShell",
                    "PowerShell-V2",
                    "DSC-Service",
                    "PowerShell-ISE",
                    "WoW64-Support")
           }
           xComputer JoinDomain {
                Name = $env:COMPUTERNAME
                DomainName = $DomainName
                Credential = $pass
           }
           ##This is just for testing before virtual network is created in customer subscription.
           #xDnsServerAddress DnsServerAddress {
           #     Address = '192.168.0.5', '8.8.8.8'
           #     AddressFamily = 'IPv4'
           #     InterfaceAlias = 'Ethernet'
           #}
        }
}