function Invoke-SQL
{
    [CmdletBinding()]
	[OutputType([System.Collections.Hashtable])]
    param(
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $ServerInstance,

        [parameter(Mandatory = $true)]
        [System.Management.Automation.PSCredential]
        $SqlAdminCredential,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $Query,

        $QueryTimeout = 30
    )

    try {
        return Invoke-SqlCmd -ServerInstance $ServerInstance -QueryTimeout $QueryTimeout `
            -Username $SqlAdminCredential.Username `
            -Password $SqlAdminCredential.GetNetworkCredential().Password `
            -Query $Query `
            -AbortOnError
    } catch	{
        throw $("Cannot call Invoke-SqlCmd`nQuery:`n######`n" + $Query + "`n######`n" + $_);
    }
}

function Set-SQLMemorySettings
{
    [CmdletBinding()]
    param(
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $ServerInstance,

        [parameter(Mandatory = $true)]
        [System.Management.Automation.PSCredential]
        $SqlAdminCredential,

        $MinServerMemory,

        $MaxServerMemory
    )

        $query = @"
sp_configure 'show advanced options', 1;
GO
RECONFIGURE;
GO
sp_configure 'max server memory', $MaxServerMemory;
GO
RECONFIGURE;
GO
sp_configure 'min server memory', $MinServerMemory;
GO
RECONFIGURE;
GO
"@
    return Invoke-Sql -ServerInstance $ServerInstance `
        -SqlAdminCredential $SqlAdminCredential `
        -Query $query `
}

function Get-SQLMemorySettings
{
    [CmdletBinding()]
	[OutputType([System.Collections.Hashtable])]
    param(
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $ServerInstance,

        [parameter(Mandatory = $true)]
        [System.Management.Automation.PSCredential]
        $SqlAdminCredential
    )

    $query = @"
sp_configure 'show advanced options', 1;
GO
RECONFIGURE;
GO
sp_configure 'max server memory';
GO
sp_configure 'min server memory'; 
GO
"@
    
    return Invoke-Sql -ServerInstance $ServerInstance -SqlAdminCredential $SqlAdminCredential -Query $query | 
    % -Begin { $hash = @{ MinServerMemory = ''; MaxServerMemory = '' } } -Process {
        $key = if ($_.Name.StartsWith('max')) { 'MaxServerMemory' } else { 'MinServerMemory' }
        $hash[ $key ] = $_.config_value
    } -End { $hash }
}

function Set-SQLTraceFlagGlobally
{
    [CmdletBinding()]
	[OutputType([System.Collections.Hashtable])]
    param(
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $ServerInstance,

        [parameter(Mandatory = $true)]
        [System.Management.Automation.PSCredential]
        $SqlAdminCredential,

        $TraceFlagNumber,

        $Enable
    )
    $verb = if ($Enable) { 'TRACEON' } else { 'TRACEOFF' }
    $query = @"
DBCC $verb ($TraceFlagNumber, -1)
GO
"@
    return Invoke-Sql -ServerInstance $ServerInstance -SqlAdminCredential $SqlAdminCredential -Query $query 
}

function Get-SQLTraceFlagGlobally
{
    [CmdletBinding()]
    param(
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $ServerInstance,

        [parameter(Mandatory = $true)]
        [System.Management.Automation.PSCredential]
        $SqlAdminCredential,

        $TraceFlagNumber
    )

    $query = @"
DBCC TRACESTATUS ($TraceFlagNumber, -1);
GO
"@
    return Invoke-Sql -ServerInstance $ServerInstance -SqlAdminCredential $SqlAdminCredential -Query $query 
}

function Get-SQLServiceAccountName
{
     param(
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $InstanceName
    )

    $iName = $InstanceName.ToUpper()
    Get-WmiObject -Class Win32_Service | 
        ? { $_.Name.Contains($iName) } | 
            Select -ExpandProperty StartName | Sort -Unique
}

function Set-SQLVolumePrivilege
{
    param(
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $InstanceName
    )

    # php style!
    . "$PSScriptRoot\Add-LoginToLocalPrivilege.ps1"

    Get-SQLServiceAccountName -InstanceName $InstanceName | % {
        Add-LoginToLocalPrivilege -DomainAccount $_ -Privilege 'SeManageVolumePrivilege' -Verbose -WhatIf:$False -Confirm:$False
    }
}

function Get-SeManageVolumePrivilege
{
    $tempFile = "$env:TEMP\currentUserRIGHTS.inf"
    $out = & secedit /export /areas USER_RIGHTS /cfg $tempFile 
    if (($? -eq $True) -and (Test-Path -Path $tempFile))
    {
        try 
        {
            $userNames = Get-Content -Path $tempFile | ? { 
                $_.StartsWith('SeManageVolumePrivilege') 
            } | % { 
                ($_ -split '=')[1].Trim() -Split ',' 
            } | % {
                $sid = if ($_.StartsWith('*')) { $_.Substring(1) } else { $_ }
                Write-Verbose "Found sid: $sid. Trying find username."
                (New-Object System.Security.Principal.SecurityIdentifier ($sid)).Translate([System.Security.Principal.NTAccount])
            } | Select -ExpandProperty Value

            Write-Verbose "Usernames in SeManageVolumePrivilege: $userNames"
            $userNames
        }
        finally
        {
            Write-Verbose "Removing temp file '$tempFile'"
            Remove-Item -Path $tempFile -Force
        }
    }
    else
    {
        throw "command 'secedit /export /areas USER_RIGHTS /cfg $tempFile' was failed. `nOutput: $out `nCan not get current user rights!"
    }
}

function Get-SQLVolumePrivilege
{
    param(
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $InstanceName
    )

    $sqlAccounts = Get-SQLServiceAccountName -InstanceName $InstanceName 
    Get-SeManageVolumePrivilege | ? {
        $_ -in $sqlAccounts
    }
}

Export-ModuleMember -Function *-SQLTraceFlagGlobally, *-SQLMemorySettings, *-SQLVolumePrivilege