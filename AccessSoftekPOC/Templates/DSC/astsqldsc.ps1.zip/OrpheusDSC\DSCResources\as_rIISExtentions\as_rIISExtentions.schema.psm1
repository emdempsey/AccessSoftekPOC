Configuration as_rIISExtentions {
<#
  .SYNOPSIS
  Install IIS Modules (see spec. https://cf.mfmnow.com/display/Automation/Specifications+for+automation#Specificationsforautomation-IISExtensions)

  .DESCRIPTION
  * Install:
    * Odata
    * AppDev
    * URL Rewrite
    * WFF
    * ARR


  .PARAMETER Ensure
  Status: Absent or Ensure

  .NOTES
  (C) Access Softek 2015
  Ruslan Kalakutsky, rkalakutsky@accesssoftek.com

#>
  param (
      [parameter(Mandatory=$true)]
      [ValidateSet("Present","Absent")]
      [string] $Ensure,

      [parameter(Mandatory=$true)]
      [string[]] $Extentions
  )

  # TODO: need to change hardcoded variable
  $WebPi = "C:\ProgramData\chocolatey\bin\WebpiCmd-x64.exe"

  ForEach ($exten in $Extentions) {

    if ($exten.Contains("Odata")) {
      # Install OData
      as_pFeatures OData {
        Ensure      = "$Ensure"
        Features    = @("ManagementOdata")
      }
    }

    if ($exten.Contains("AppDev")) {
      # Install AppDev
      as_pFeatures AppDev {
        Ensure      = "$Ensure"
        Features    = @("Web-App-Dev",
                        "Web-Net-Ext",
                        "Web-Net-Ext45",
                        "Web-AppInit",
                        "Web-ASP",
                        "Web-Asp-Net",
                        "Web-Asp-Net45",
                        "Web-CGI",
                        "Web-Includes",
                        "Web-WebSockets",
                        "Web-ISAPI-Ext",
                        "Web-ISAPI-Filter")
      }
    }

    if ($exten.Contains("UrlRewrite")) {
      # Install URL Rewrite 2.0 via WebPi
      Package UrlRW {
        Ensure      = "$Ensure"
        Name        = "IIS URL Rewrite Module 2"
        Path        = "$WebPi"
        ProductId   = ''
        Arguments   = "/install /products:UrlRewrite2 /AcceptEula"
      }
    }

    if ($exten.Contains("ARR")) {
      # Install Application request routing via WebPi
      Package UrlRW {
        Ensure      = "$Ensure"
        Name        = "Microsoft Application Request Routing 3.0"
        Path        = "$WebPi"
        ProductId   = ''
        Arguments   = "/install /products:ARRv3_0 /AcceptEula"
      }
    }

    if ($exten.Contains("MSMQ")) {
      # MSMQ
      as_pFeatures AppDev {
        Ensure      = "$Ensure"
        Features    = @("MSMQ",
                        "MSMQ-Services",
                        "MSMQ-Server")
      }
    }

  } # foreach
} # conf
