﻿Configuration SQL {
        param 
	    ( 
	        [Parameter(Mandatory)]
	        [String]$DomainName,

	        [Parameter(Mandatory)]
	        [System.Management.Automation.PSCredential]$Admincreds
	    )
		
        #AST modules resource
        Import-DscResource -ModuleName OrpheusDSC

        #cTentacleAgent
        Import-DscResource -ModuleName OctopusDSC
        
        Import-DscResource -ModuleName xComputerManagement, cComputerManagement
        Import-DscResource -ModuleName xSQLServer
        Import-DscResource -ModuleName xPSDesiredStateConfiguration
                                    
		[System.Management.Automation.PSCredential ]$pass = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
        
        Node Localhost {
            cTentacleAgent OctopusTentacle {
                Ensure = "Present";
                State  = "Started";             
                Name   = "Tentacle";
                #ApiKey           = "API-000";
                #OctopusServerUrl = "https://deploy.orpheusdev.net";
                #Environments     = "test";
                #Roles            = "role";
                #ListenPort                  = "10933"
                DefaultApplicationDirectory = "$($env:SystemDrive)\Applications" # c:\Octopus;
            }
           Script SQLStartupParam1 {
                GetScript  = { return @{}; }
                TestScript = {
                    $startupParameter= "-T2371"
                    $hklmRootNode = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server"
                    $inst = "MSSQL12.MSSQLSERVER"
                    $regKey = "$hklmRootNode\$inst\MSSQLServer\Parameters"
                    $props = Get-ItemProperty $regKey
                    $params = $props.psobject.properties | ?{$_.Name -like 'SQLArg*'} | select Name, Value
                    foreach ($param in $params) {
                        if($param.Value -eq $StartupParameter) {
                            return $true
                        }
                    }
                    return $false
                }
                SetScript  = {
                    $startupParameter= "-T2371"
                    $hklmRootNode = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server"
                    $inst = "MSSQL12.MSSQLSERVER"
                    $regKey = "$hklmRootNode\$inst\MSSQLServer\Parameters"
                    $props = Get-ItemProperty $regKey
                    $params = $props.psobject.properties | ?{$_.Name -like 'SQLArg*'} | select Name, Value
                    $newRegProp = "SQLArg"+($params.Count)
                    Set-ItemProperty -Path $regKey -Name $newRegProp -Value $StartupParameter;
                }          
            }
           # Set SQL Trace Startup Parameter
           Script SQLStartupParam2 {
                GetScript  = { return @{}; }
                TestScript = {
                    $startupParameter= "-T1118"
                    $hklmRootNode = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server"
                    $inst = "MSSQL12.MSSQLSERVER"
                    $regKey = "$hklmRootNode\$inst\MSSQLServer\Parameters"
                    $props = Get-ItemProperty $regKey
                    $params = $props.psobject.properties | ?{$_.Name -like 'SQLArg*'} | select Name, Value
                    foreach ($param in $params) {
                        if($param.Value -eq $StartupParameter) {
                            return $true
                        }
                    }
                    return $false
                }
                SetScript  = {
                    $startupParameter= "-T1118"
                    $hklmRootNode = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server"
                    $inst = "MSSQL12.MSSQLSERVER"
                    $regKey = "$hklmRootNode\$inst\MSSQLServer\Parameters"
                    $props = Get-ItemProperty $regKey
                    $params = $props.psobject.properties | ?{$_.Name -like 'SQLArg*'} | select Name, Value
                    $newRegProp = "SQLArg"+($params.Count)
                    Set-ItemProperty -Path $regKey -Name $newRegProp -Value $StartupParameter;
                }          
            }
           #Change SQL Login Mode
           Script SQLLoginMode {
                GetScript  = { return @{}; }
                TestScript = {
                    import-module "sqlps" -DisableNameChecking
                    $s = new-object ('Microsoft.SqlServer.Management.Smo.Server') $env:COMPUTERNAME
                    [string]$nm = $s.Name
                    [string]$mode = $s.Settings.LoginMode
                        if($mode.Value -ilike "Mixed") {
                            return $true
                        }
                    return $false
                }
                SetScript  = {
                    $s = new-object ('Microsoft.SqlServer.Management.Smo.Server') $env:COMPUTERNAME
                    [string]$nm = $s.Name
                    [string]$mode = $s.Settings.LoginMode

                    $s.Settings.LoginMode = [Microsoft.SqlServer.Management.SMO.ServerLoginMode]::Mixed
                    $s.Alter()
                }          
            }
            Script MSDBBrokerMode {
                GetScript  = { return @{}; }
                TestScript = {
                    #$s = new-object ('Microsoft.SqlServer.Management.Smo.Server') $env:COMPUTERNAME
                    $result = Invoke-Sqlcmd -Query "SELECT is_broker_enabled FROM sys.databases where Name = 'msdb';" -ServerInstance $env:COMPUTERNAME
                        if($result = 'True') {
                            return $true
                        }
                    return $false
                }
                SetScript  = {
                    #$s = new-object ('Microsoft.SqlServer.Management.Smo.Server') $env:COMPUTERNAME
                    Invoke-Sqlcmd -Query "Alter Database msdb set enable_broker;" -ServerInstance $env:COMPUTERNAME
                }          
            }
            xSQLServerFirewall Setup-Firewall-SQL {
                Ensure = "Present"
		        SourcePath = "C:\SQLServer_12.0_Full"
		        SourceFolder = "\"
		        Features = "SQLENGINE,FULLTEXT,RS,SSMS,ADV_SSMS"
		        InstanceName = "MSSQLSERVER"
            }
            pWindowsUpdates WindowsUpdates-BasicSetup {
                UniqKeyName = "SQLserver"
                Ensure = "Present"
                KBArticleID = @()
                UpdateID = @()
            }
            cComputer JoinDomain {
                Name = $env:COMPUTERNAME
                DomainName = $DomainName
                Credential = $pass
                DependsOn = "[pWindowsUpdates]WindowsUpdates-BasicSetup"

           }
      }
}