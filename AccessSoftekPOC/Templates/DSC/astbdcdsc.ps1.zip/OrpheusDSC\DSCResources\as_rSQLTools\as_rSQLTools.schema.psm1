Configuration as_rSQLTools {
<#
  .SYNOPSIS
  Install SQL Tools (see spec. https://cf.mfmnow.com/display/Automation/Specifications+for+automation#Specificationsforautomation-SQLTools)

  .DESCRIPTION
  * Install some SQL tools like NAtive Client, Shared object, etc.

  .PARAMETER Ensure
  Status: Absent or Ensure

  .NOTES
  (C) Access Softek 2015
  Tetsuya Chiba, tchiba@accesssoftek.com
  Ruslan Kalakutsky, rkalakutsky@accesssoftek.com


#>
  param (
      [parameter(Mandatory=$true)]
      [ValidateSet("Present","Absent")]
      [string] $Ensure
  )

  # ChocolateyDSC
  Import-DscResource -ModuleName ChocolateyDSC

  # Packages installed:
  #   * SQL Server 2012 System CLR Types
  #   * Microsoft SQL Server 2012 Management Objects
  #   * Microsoft .NET Framework 4.5 Multi-Targeting Pack
  #   * Microsoft .NET Framework 4.5 SDK
  #   * Microsoft Help Viewer 2.0
  #   * Microsoft Visual Studio 2012 Shell (Isolated)
  #   * Microsoft SQL Server Data Tools 2012
  #   ... and a lot more
  #
  # Install with Chocolatey, because it's approved.

  # Install manually because choco has broken package
  xPackage SSDT {
    Ensure    = "Present"
    Name      = "Microsoft SQL Server Data Tools 2012"
    Path = "http://download.microsoft.com/download/4/9/0/4907755D-5E4A-4369-8E8D-E30FA7D22F22/EN/SSDTSetup.exe"
    ProductId = ""
    Arguments = "/norestart /q"
  }

  #cChocolateyPackage SSDT {
  #  PackageName = "ssdt11"
  #  Ensure = "Present"
  #}

  # Install manually
  xPackage PowerShellSQLExtensions {
    Ensure = "Present"
    Name = "Windows PowerShell Extensions for SQL Server 2012 "
    Path = "http://download.microsoft.com/download/F/E/D/FEDB200F-DE2A-46D8-B661-D019DFE9D470/ENU/x64/PowerShellTools.MSI"
    ProductId = ""
    Arguments = "/norestart IACCEPTSQLNCLILICENSETERMS=YES"
    DependsOn = "[xPackage]SSDT" # component "Microsoft SQL Server 2012 Management Objects"
  }

  #xPackage SQLSystemCRL {
  #  Ensure    = "Present"
  #  Name      = "SQL Server 2012 System CLR Types"
  #  Path      = "http://download.microsoft.com/download/0/D/2/0D2D9A1F-1461-46DC-9CB9-62A43B26B672/ENU/x64/SQLSysClrTypes.msi"
  #  ProductId = ""
  #  Arguments = "/norestart IACCEPTSQLNCLILICENSETERMS=YES"
  #}
  #

  # Install manually, because SSDT tools do not include x64 version of SMO (x86 only). And there is no x64 version of SSDT.
  xPackage SQLServerManagementObjects {
    Ensure = "Present"
    Name = "Microsoft SQL Server 2012 Management Objects  (x64)"
    Path = "http://download.microsoft.com/download/F/E/D/FEDB200F-DE2A-46D8-B661-D019DFE9D470/ENU/x64/SharedManagementObjects.msi"
    ProductId = ""
    Arguments = "/norestart IACCEPTSQLNCLILICENSETERMS=YES"
    #DependsOn = "[xPackage]SQLSystemCRL"
    DependsOn = "[xPackage]SSDT" # component "SQL Server 2012 System CLR Types"
  }

  # Install manually, because it is on moderation and has not been approved on choco
  xPackage SQLNativeClient {
    Ensure = "Present"
    Name = "Microsoft SQL Server 2012 Native Client "
    Path = "http://download.microsoft.com/download/F/E/D/FEDB200F-DE2A-46D8-B661-D019DFE9D470/ENU/x64/sqlncli.msi"
    ProductId = ""
    Arguments = "/norestart IACCEPTSQLNCLILICENSETERMS=YES"
  }

  # Install manually
  xPackage SQLCmdLnUtils {
    Ensure = "Present"
    Name = "Microsoft SQL Server 2012 Command Line Utilities "
    Path = "http://download.microsoft.com/download/F/E/D/FEDB200F-DE2A-46D8-B661-D019DFE9D470/ENU/x64/SqlCmdLnUtils.msi"
    ProductId = ""
    Arguments = "/norestart"
    DependsOn = "[xPackage]SQLNativeClient"
  }
}
