﻿Configuration BDC {
        param 
	    ( 
	        [Parameter(Mandatory)]
	        [String]$DomainName,

	        [Parameter(Mandatory)]
	        [System.Management.Automation.PSCredential]$Admincreds
	    )
		
        #AST modules resource
        Import-DscResource -ModuleName OrpheusDSC

        Import-DscResource -ModuleName xActiveDirectory
                    
		[System.Management.Automation.PSCredential ]$pass = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
                
        Node Localhost {
           as_pFeatures EnFeature {
                Ensure = "Present"
                Features    = @("Telnet-Client",
                    "PowerShell",
                    "PowerShell-V2",
                    "DSC-Service",
                    "PowerShell-ISE",
                    "WoW64-Support",
                    "AD-Domain-Services")
           }
           User DomainAdmin {
                Ensure = "Present"
                UserName = "nimda"
                Password = $pass
           }
           xWaitForADDomain DscForestWait { 
                DomainName = $DomainName
                DomainUserCredential = $pass
                RetryCount = 60
                RetryIntervalSec = 30
                DependsOn = "[as_pFeatures]EnFeature" #, "[xDNSServerAddress]DnsServerAddress" #remove dnsserver later
           } 
           xADDomainController SecondDC { 
                DomainName = $DomainName
                DomainAdministratorCredential = $pass
                SafemodeAdministratorPassword = $pass
                DependsOn = "[xWaitForADDomain]DscForestWait"
           }            
        }
}