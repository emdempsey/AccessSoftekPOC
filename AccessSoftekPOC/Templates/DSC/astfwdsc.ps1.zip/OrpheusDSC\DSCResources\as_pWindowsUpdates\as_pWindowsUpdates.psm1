﻿function Get-TargetResource
{
    [OutputType([System.Collections.Hashtable])]
    param
    (
        [parameter(Mandatory)]
        [string] $UniqKeyName,

        [ValidateSet("Present","Absent")]
        [string] $Ensure,

        [string[]] $KBArticleID,

        [string[]] $UpdateID
    )

    Write-Verbose "Get-TargetResource starting"
    $VerbosePreference = "Continue"
    $PSBoundParameters.Remove("uniqKeyName")
	ImportNestedModules @PSBoundParameters
    Write-Verbose "Getting all installed updates"
	$updatesList = Get-WUList -ComputerName localhost -IsInstalled -Verbose
    Write-Verbose "Installed $($updatesList.Count) updates"
	
	$returnValue = @{
		uniqKeyName = $uniqKeyName
		Ensure = 'Present'
		KBArticleID = Get-Kbs $updatesList 
		UpdateID = Get-UpdateIds $updatesList
	}
	
	$returnValue
}

function Set-TargetResource
{
    param
    (
        [parameter(Mandatory)]
        [string] $UniqKeyName,

        [ValidateSet("Present","Absent")]
        [string] $Ensure,

        [string[]] $KBArticleID,

        [string[]] $UpdateID
    )

    $VerbosePreference = "Continue"
    Write-Verbose "Set-TargetResource starting"
    ImportNestedModules @PSBoundParameters
    
    if ($Ensure -eq 'Present') 
    {
        $installResult = Get-WUInstall -KBArticleID $KBArticleID `
            -UpdateID $UpdateID -AcceptAll -IgnoreReboot -Verbose

        if ($installResult)
        {
            Write-Verbose "Installing updates return: '$installResult'"
        }
        else
        {
            Write-Verbose "Installing updates return empty value"
        }

        #if ("Reboot is required, but do it manually." -eq $installResult) 
        #{
        #    $global:DSCMachineStatus = 1
        #}
        $objSystemInfo = New-Object -ComObject "Microsoft.Update.SystemInfo"	
		if ($objSystemInfo.RebootRequired)
        {
            $global:DSCMachineStatus = 1
        }
    }
    else
    {
        throw "[as_pWindowsUpdates]Set-TargetResource: Ensure = 'Absent' is not implemented."
    }
}

function Test-TargetResource
{
	[OutputType([System.Boolean])]
	[CmdletBinding()]
	param
	(
        	[parameter(Mandatory)]
	        [string] $UniqKeyName,

            [ValidateSet("Present","Absent")]
	        [string] $Ensure,

	        [string[]] $KBArticleID,

	        [string[]] $UpdateID
    	)

	$VerbosePreference = "Continue"
    
	ImportNestedModules @PSBoundParameters
    Write-Verbose "Test-TargetResource starting"
    
    if ($Ensure -eq "Present")
    {
        if ($KBArticleID -eq $null -and $UpdateID -eq $null)
        {
            Write-Verbose "KBArticleID and UpdateID are null. Trying find available updates"
            $updatesList = Get-WUInstall -ListOnly -Verbose
            Write-Verbose "Find $($updatesList.Count) updates"
            # don`t do Set-TargetResource if no available updates 
            return ($updatesList.Count -eq 0)
        }
        
        $installed = Get-TargetResource @PSBoundParameters
        $updatesList = @()
        $needKbUpdateIDs = @()
        $needKbSet = @()
        
        if ($KBArticleID -ne $null)
        {
            Write-Verbose "You request that KBs: $($KBArticleID -join ', ') should be already installed"
            $needKbSet = Get-HashSet $KBArticleID
            $needKbSet.ExceptWith([string[]]$installed.KBArticleID)
        }
        
        if ($UpdateID -ne $null)
        {
            Write-Verbose "You request that UpdateIDs: $($UpdateID -join ', ') should be installed"
            $needKbUpdateIDs = Get-HashSet $UpdateID
            $needKbUpdateIDs.ExceptWith([string[]]$installed.UpdateID)
        }

        if ($needKbSet.Count -ne 0 -or $needKbUpdateIDs -ne 0)
        {
            $updatesList = Get-WUInstall -ListOnly -Verbose
            Write-Verbose "Find $($updatesList.Count) updates are available online"
        }

        $testResult = $True

        if ($needKbSet.Count -ne 0)
        {
            $onlineKbs = Get-Kbs $updatesList 
            $count = $needKbSet.Count
            Write-Verbose "Find KBs are not installed: $( $needKbSet -join ', ')"
            Write-Verbose "Count not installed: $count"
            if ($onlineKbs.Count -gt 0)
            {
                $needKbSet.ExceptWith([string[]]$onlineKbs)
            }
            
            if ($needKbSet.Count -eq 0)
            {
                Write-Verbose "Found all requested kbs in online store"
                # the actual status of the resource instance does not match the values specified in the parameter
                $testResult = $False
            }
            elseIf ($count -ne $needKbSet.Count)
            {
                Write-Verbose "Found NOT all requested kbs in online store"
                # the actual status of the resource instance does not match the values specified in the parameter
                $testResult = $False
            }

            if ($needKbSet.Count -gt 0)
            {
                Write-Verbose "Can not find '$( $needKbSet -join ', ')' in online store."
                Write-Warning "Can not find '$( $needKbSet -join ', ')' in online store."
            }            
        } 
        else 
        {
            Write-Verbose "All requested KBs already are installed"
        }

        if ($needKbUpdateIDs.Count -ne 0)
        {
            $online = Get-UpdateIds $updatesList 
            $count = $needKbUpdateIDs.Count
            Write-Verbose "Find UpdateIDs are not installed: $($needKbUpdateIDs -join ', ')"
            Write-Verbose "Count not installed: $count"
            if ($online.Count -gt 0)
            {
                $needKbUpdateIDs.ExceptWith([string[]]$online)
            }
            
            if ($needKbUpdateIDs.Count -eq 0)
            {
                Write-Verbose "Found all requested updateID in online store"
                # the actual status of the resource instance does not match the values specified in the parameter
                $testResult = $False
            }
            elseIf($count -ne $needKbUpdateIDs.Count)
            {
                Write-Verbose "Found NOT all requested updateID in online store"
                # the actual status of the resource instance does not match the values specified in the parameter
                $testResult = $False
            }

            if ($needKbUpdateIDs.Count -gt 0)
            {
                Write-Verbose "Can not find '$( $needKbUpdateIDs -join ', ')' in online store."
                Write-Warning "Can not find '$( $needKbUpdateIDs -join ', ')' in online store."
            }
        }
        else 
        {
            Write-Verbose "All requested UpdateIDs already are installed"
        }

        return $testResult
    }

    return $True
}

function ImportNestedModules
{
    $nestedModules = $('Get-WUInstall', 'Get-WUList')
    $currentDir = if ($PSScriptRoot -eq '') { Split-Path -parent $MyInvocation.MyCommand.Definition } else { $PSScriptRoot }

    if (-Not (Get-Module | Where-Object -Property Name -IN $nestedModules))
	{   
        Write-Verbose "1 Import nested modules $($nestedModules -join ', ')"
        $nestedModules | % { Import-Module "$currentDir\PSWindowsUpdates\$_.psm1" }
	}
}

function Get-HashSet
{
    [CmdletBinding()]
    [OutputType([System.Collections.Generic.HashSet[String]])]
    param(
        [System.String[]] $Strings
    )
    
    [System.Collections.Generic.HashSet[String]] $set = New-Object System.Collections.Generic.HashSet[String] 
    if ($Strings)
    {
        $set.UnionWith( [System.String[]]$Strings )
    }     
     
    $PSCmdlet.WriteObject($set)
}

function Get-Kbs
{
    param(
        $listUpdates
    )

    # Select -ExpandProperty  does not work, because comObject
    $listUpdates | % { $_.KBArticleIDs | % { "KB$($_)" } }
}

function Get-UpdateIds
{
    param(
        $listUpdates
    )
    $listUpdates | % { $_.Identity.UpdateID }
}


Export-ModuleMember -Function Test-TargetResource,Get-TargetResource,Set-TargetResource
