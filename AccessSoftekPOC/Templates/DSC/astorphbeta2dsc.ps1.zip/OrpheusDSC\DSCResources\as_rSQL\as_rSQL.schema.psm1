Configuration as_rSQL {
<#
  .SYNOPSIS
  Install MS SQL Server

  .DESCRIPTION
  * Install 

  .PARAMETER Ensure
  

  .NOTES
  (C) Access Softek 2015
#>

    <#
        When a configuration is created, it automatically receives three default parameters:
        InstanceName, OutputPath, and ConfigurationData.
    #>
    param (
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $InstanceSQLServiceName,

        [parameter(Mandatory = $true)]
        [System.Management.Automation.PSCredential]
        $SetupCredential,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $SourceUri,

        [System.String]
        [ValidateSet("", "zip", "iso")]
        $SourceUriFileType = '',

        [System.String]
        $TemporaryStorageDir = 'C:\Windows\temp',

        #[System.Management.Automation.PSCredential]
		#$SQLSvcAccount,

        [parameter(Mandatory = $true)]
        [System.Management.Automation.PSCredential]
        $SAPwd,

        [System.String[]]
        $SQLSysAdminAccounts,

        [System.String]
        $ProductLicensKey,

        [System.String]
		$InstanceDir
    )

    Import-DscResource -ModuleName xSQLServer

    Import-DscResource -ModuleName xPSDesiredStateConfiguration

    # 0.1) Deliver iso/archive with installation packages MSSQL services

    $fileName =  Split-Path $SourceUri -Leaf
    $TemporaryStorageDir = [System.IO.Path]::GetFullPath($TemporaryStorageDir)
	$installationFilePath = Join-Path $TemporaryStorageDir $fileName
    $SourceFolder = [System.String]::Format("\sqlServer{0:ddyyyy}", [System.DateTime]::Today)
    $SourcePath = "${TemporaryStorageDir}$SourceFolder"
    $Features = "SQLENGINE,FULLTEXT,RS,SSMS,ADV_SSMS" # SQLENGINE,FULLTEXT,RS,AS,IS,SSMS,ADV_SSMS # what about 'TOOLS'?

    Script 'GettingSourceInstallation' {
        GetScript = { @{} }

        SetScript = {
            $dir =  Split-Path $using:installationFilePath -Parent
            if (-not (Test-Path -Path $dir))
            {
                New-Item -Type Directory -Path $dir -Force
            }

            Write-Verbose "Trying download file '$using:SourceUri' to '$installationFilePath'"
            ( New-Object System.Net.WebClient ).DownloadFile($SourceUri, $installationFilePath)
        }

        TestScript = {
	        if (Test-Path -Path $using:installationFilePath) {
		        Write-Verbose "File '$installationFilePath' exists"
		        $true
	        } 
            else 
            {
                $false
            }
        }
    }

    <#
    # NOTE: OutOfMemory exception on big files :( 
    xRemoteFile 'GettingSourceInstallation' {
        Uri = $SourceUri
        DestinationPath = $TemporaryStorageDir
    }
    #>
    $fileExtension = [system.IO.Path]::GetExtension($fileName)
    $nextStepDependency = ''
    if ($fileExtension -eq '.zip' -or $SourceUriFileType -eq 'zip')
    {
        # NOTE: Supports only zip archive :(
        xArchive ExpandInstallationSource {
            Path = $installationFilePath
            Destination = $SourcePath
            #CompressionLevel = $CompressionLevel
            DestinationType = 'Directory'
            MatchSource = $False
            DependsOn = '[Script]GettingSourceInstallation'
        }

        $nextStepDependency = '[xArchive]ExpandInstallationSource'
    } 
    elseif ($fileExtension -eq '.iso' -or $SourceUriFileType -eq 'iso')
    {
        Script ExpandInstallationSource {
            getScript = { @{} }

            setScript = {
                function Expand-IsoImage
                {
                    [CmdletBinding()]
                    param([System.String]$Destination, [System.String]$ImagePath)

                    Write-Verbose "Mounting image '$ImagePath'"
                    $volume = Mount-DiskImage -ImagePath $ImagePath -PassThru | Get-Volume
        
                    <#Get-Volume | % {
                        Write-Verbose "Attached disk: $($_.DriveLetter) $($_.FileSystem) $($_.HealthStatus) $($_.FileSystemLabel)"
                    } #>

                    try{
                        Write-Verbose "Mounted as '$($volume.DriveLetter):\'"
                        if ( -not (Test-path -Path $Destination))
                        {
                            Write-Verbose "Create new directory '$Destination'"
                            New-Item -Type Directory -Path $Destination
                        }

                        Write-Verbose "Copy all content to '$Destination'"
                    
                        & powershell -Command "Copy-Item -Path '$($volume.DriveLetter):\*' -Destination $Destination -Force -Recurse"
                    
                        # NOTE: Copy-item does NOT work after mount disk, I think it is dsc engine feature... :(
                        # it throw error "Cannot find drive. A drive with the name 'NewDriveHere' does not exist."
                        # may be bug in Globber, maybe no reinit driverInfo collection in System.Management.Automation.SessionStateInternal

                        #Trace-Command -Name LocationGlobber,FileSystemProvider,PSDriveInfo,PathResolution `
                        #    -Expression { Copy-Item -Path "$($volume.DriveLetter):\*" -Destination $SourcePath -Force -Recurse } `
                        #    -PSHost
                        #Write-Verbose ((& cmd /C dir "k:\") -join '`n' )
                        #Invoke-Command -ScriptBlock { Copy-Item -Path '$($volume.DriveLetter):\*' -Destination $SourcePath -Force -Recurse }
                    }
                    catch
                    {
                        throw $_
                    }
                    finally {
                        DisMount-DiskImage -ImagePath $ImagePath
                    }
                }

                Expand-IsoImage -Destination $using:SourcePath -ImagePath $using:installationFilePath
            }

            testScript = {
                function Test-NeedCopyFromIso
                {
                    [CmdletBinding()]
                    param([System.String]$SourcePath, [System.String]$ImagePath)

                    $nSourcePath = [IO.Path]::GetFullPath($SourcePath)
                    $getFilesDesc =  {
                        Get-ChildItem -Recurse -Path "$nSourcePath" | ? { -Not ($_ -is [System.IO.DirectoryInfo]) } | % { 
                            [string](($_.FullName -Split "$nSourcePath", 0, 'simplematch') + '|' + $_.LastWriteTime.Ticks + '|' + 
                                $_.Length)
                        }
                    }

                    $localFiles = . $getFilesDesc | Sort
                    if (-Not ($localFiles) )
                    {
                        # No files in dir
                        Write-Verbose "Didn``t find any files in '$SourcePath'"
                        $False
                    }
                    else
                    {
                        Write-Verbose "Mounting image '$($ImagePath)'"
                        $volume = Mount-DiskImage -ImagePath $ImagePath -PassThru | Get-Volume
                        try
                        {
                            $null -eq (Compare-Object -ReferenceObject $localFiles `
                            -DifferenceObject (& powershell -Command ($getFilesDesc -replace '\$nSourcePath', "'$($volume.DriveLetter):'") | Sort) -PassThru)
                        }
                        catch
                        {
                            throw $_
                        }
                        finally
                        {
                            Write-Verbose "DisMounting image '$($ImagePath)'"
                            DisMount-DiskImage -ImagePath $ImagePath | Out-Null
                        }
                    }
                }

                Test-NeedCopyFromIso -SourcePath $using:SourcePath -ImagePath $using:installationFilePath
            }
        }

        $nextStepDependency = '[Script]ExpandInstallationSource'
    }
    else 
    {
        throw 'Can download and expand only "iso" or "zip" file.' + 
            (if ($SourceUriFileType -eq '') { 'Please, use param "SourceUriFileType" for expliced set file type.' } else { '' })
    }
    
    # 0 Create service account for SQL services

    User "SetupCredential-$($SetupCredential.UserName)" {
        UserName = $SetupCredential.UserName
        Disabled = $False
        Ensure = 'Present'
        Password = $SetupCredential
        PasswordChangeNotAllowed = $False
        PasswordChangeRequired = $False
        PasswordNeverExpires = $True
        DependsOn = $nextStepDependency
    }
    
    # 1) Install Microsoft SQL Server 2012 Standard Edition (64 bit)
    xSQLServerSetup 'Install-SQL' {
		SourcePath = $TemporaryStorageDir
        # NOTE: SetupCredential used as sa user for each services + 
        # if source path is network share path (start with `\\`), SetupCredential used in `net use` command
        SetupCredential = $SetupCredential
		SourceFolder = $SourceFolder
		Features = $Features
		InstanceName = $InstanceSQLServiceName
        # NOTE: if it is empty string - eveluation mode
		PID = $ProductLicensKey
	    InstanceDir = $InstanceDir
		#SQLSvcAccount =   #$SQLSvcAccount
		SQLCollation = 'SQL_Latin1_General_CP1_CI_AS'
		SQLSysAdminAccounts = $SQLSysAdminAccounts
        # NOTE: Mixed mode
		SecurityMode = 'SQL'
		SAPwd = $SAPwd
        # NOTE: Microsoft updates (MU) - source of updates
        UpdateSource = 'MU'
        DependsOn = "[User]SetupCredential-$($SetupCredential.UserName)"
    }

    # 2) Setup Windows Firewall Rule
    xSQLServerFirewall 'Setup-Firewall-SQL' {
        Ensure = "Present"
		SourcePath = $TemporaryStorageDir
		SourceFolder = $SourceFolder
		Features = $Features
		InstanceName = $InstanceSQLServiceName
        DependsOn = "[xSQLServerSetup]Install-SQL"
    }

    # 3) Install windows updates for MS SQL Server product
    pWindowsUpdates 'windowsUpdates-BasicSetup' {
        UniqKeyName = "SQLserver"
        Ensure = "Present"
        KBArticleID = @()
        UpdateID = @()
        DependsOn = "[xSQLServerSetup]Install-SQL"
    }
}

Export-ModuleMember -Function as_rSQL