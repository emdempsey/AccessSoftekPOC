﻿configuration FW
{
    param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
	    [String]$octRole,
            
        [Parameter(Mandatory)]
	    [String]$octEnv,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Parameter(Mandatory)]
        [String]$SharePath,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    )
    #AST modules resource
    Import-DscResource -ModuleName OrpheusDSC

    #cTentacleAgent
    Import-DscResource -ModuleName OctopusDSC
    
    Import-DscResource -ModuleName xComputerManagement, xActiveDirectory, xNetworking
    Import-DscResource -ModuleName xSmbShare

    [System.Management.Automation.PSCredential ]$pass = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    Node localhost
    {
        WindowsFeature ADPS
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        }
        #cTentacleAgent OctopusTentacle {
           #     Ensure = "Present";
           #     State  = "Started";             
           #     Name   = "Tentacle";
           #     ApiKey           = "API-GQNOB8UJDWA3V58ON9BGNEBZDYY";
           #     OctopusServerUrl = "https://deploy.orpheusdev.net";
           #     Environments     = @($octEnv);
           #     Roles            = @($octRole);
           #     ListenPort                  = "10933"
           #     DefaultApplicationDirectory = "c:\Applications"
           #} 
        xDnsServerAddress DnsServerAddress {
                Address = '10.0.15.4', '10.0.15.5'
                AddressFamily = 'IPv4'
                InterfaceAlias = 'Ethernet'
           } 
        xComputer JoinDomain {
                Name = $env:COMPUTERNAME
                DomainName = $DomainName
                Credential = $pass
                DependsOn = "[xDnsServerAddress]DnsServerAddress"
           }
        File FSWFolder
        {
            DestinationPath = "C:\$($SharePath.ToUpperInvariant())"
            Type = "Directory"
            Ensure = "Present"
            DependsOn = "[xComputer]DomainJoin"
        }
        xSmbShare FSWShare
        {
            Name = $SharePath.ToUpperInvariant()
            Path = "c:\$($SharePath.ToUpperInvariant())"
            FullAccess = "BUILTIN\Administrators"
            Ensure = "Present"
            DependsOn = "[File]FSWFolder"
        }
        LocalConfigurationManager {
                RebootNodeIfNeeded = $true
        }
    }     
}
