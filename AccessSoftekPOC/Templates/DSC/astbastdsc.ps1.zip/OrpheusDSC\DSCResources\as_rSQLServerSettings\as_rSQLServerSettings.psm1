<#
    #Load assemblies 
    [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo");
    [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.ConnectionInfo");
#>

$TRACE_FLAG_AUTO_UPDATE_STATISTIC = 2371 #�Auto Create Statistics� and �Auto Update Statistics�, 


Import-Module -Name "$PSScriptRoot\Utils\SQLSettings.psm1"



function Get-TargetResource
{
	[CmdletBinding()]
	[OutputType([System.Collections.Hashtable])]
	param
	(
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $InstanceName,

        [parameter(Mandatory = $true)]
        [System.Management.Automation.PSCredential]
        $SqlAdminCredential
    )

    Write-Verbose "start Get-TargetResource as_rSQLServerSettings"
    $memories = Get-SQLMemory -ServerInstance "localhost\$InstanceName" -SqlAdminCredential $SqlAdminCredential

    return @{
        InstanceName = $InstanceName
        SqlAdminCredential = $SqlAdminCredential
        MinServerMemory = $memories.MinServerMemory
        MaxServerMemory = $memories.MaxServerMemory
        EnableAutoUpdateStatisticGlobally = Get-TraceFlagGlobally -ServerInstance "localhost\$InstanceName" `
            -SqlAdminCredential $SqlAdminCredential -TraceFlagNumber $TRACE_FLAG_AUTO_UPDATE_STATISTIC | % {
                $_.Global -eq -1
            }
    }
}

function Set-TargetResource
{
	[CmdletBinding()]
	param
	(
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $InstanceName,

        [parameter(Mandatory = $true)]
        [System.Management.Automation.PSCredential]
        $SqlAdminCredential,

        [System.String]
        $MinServerMemory,

        [System.String]
        $MaxServerMemory,

        [System.Boolean]
        $EnableAutoUpdateStatisticGlobally
    )

    Write-Verbose "start Set-TargetResource as_rSQLServerSettings"

    Set-SQLMemory -ServerInstance "localhost\$InstanceName" -SqlAdminCredential $SqlAdminCredential `
        -MinServerMemory $MinServerMemory `
        -MaxServerMemory $MaxServerMemory

    Set-TraceFlagGlobally -ServerInstance "localhost\$InstanceName" -SqlAdminCredential $SqlAdminCredential `
        -TraceFlagNumber $TRACE_FLAG_AUTO_UPDATE_STATISTIC `
        -Enable $EnableAutoUpdateStatisticGlobally
}

function Test-TargetResource
{
	[CmdletBinding()]
	[OutputType([System.Boolean])]
	param
	(
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $InstanceName,

        [parameter(Mandatory = $true)]
        [System.Management.Automation.PSCredential]
        $SqlAdminCredential,

        [System.String]
        $MinServerMemory,

        [System.String]
        $MaxServerMemory
    )

    Write-Verbose "start Test-TargetResource as_rSQLServerSettings"


    return $True
}

function Test-SqlInstalled
{
    [CmdletBinding()]
	[OutputType([System.Boolean])]
	param
	(
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.String]
        $InstanceName,

        [parameter(Mandatory = $true)]
        [System.Management.Automation.PSCredential]
        $SqlAdminCredential,

        [System.String]
        $MinServerMemory,

        [System.String]
        $MaxServerMemory
    )

    #Import-Module -Name 'xSQLServer\DSCResources\MSFT_xSQLServerSetup\MSFT_xSQLServerSetup.psm1' -Prefix xSql -Function Test-TargetResource
    #$testResult = Test-xSqlTargetResource -SourcePath $TemporaryStorageDir -SourceFolder $SourceFolder -SetupCredential $SetupCredential -Features $Features -InstanceName $InstanceName
    #Write-Verbose "Test-SqlInstalled return '$testResult'"
    #$testResult
    $True
}

Export-ModuleMember -Function *-TargetResource