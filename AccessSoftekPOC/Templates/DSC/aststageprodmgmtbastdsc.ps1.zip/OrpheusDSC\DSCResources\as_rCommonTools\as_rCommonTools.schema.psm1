Configuration as_rCommonTools {
<#
  .SYNOPSIS
  Install CommonTools (see spec. https://cf.mfmnow.com/display/Automation/Specifications+for+automation#Specificationsforautomation-CommonTools)

  .DESCRIPTION
  * Ensure PowerSheel and DSC is installed and work.
  * Install and Configure Chocolatey

  .PARAMETER Ensure
  Status: Absent or Ensure

  .PARAMETER ChocolateyPath
  * Chocolatey path (use default if omitted)

  .NOTES
  (C) Access Softek 2015
  Maxim Nasonov, mnasonov@accesssoftek.com
  Tetsuya Chiba, tchiba@accesssoftek.com
  Ruslan Kalakutsky, rkalakutsky@accesssoftek.com

#>
  param (
      [parameter(Mandatory=$true)]
      [ValidateSet("Present","Absent")]
      [string] $Ensure,

      [parameter(Mandatory=$false)]
      [string] $ChocolateyPath = ""
  )

  # as_pFeatures resource
  # Import-DscResource -Name as_pFeatures

  # xRemoteFile
  Import-DscResource -ModuleName xPSDesiredStateConfiguration

  # ChocolateyDSC
  Import-DscResource -ModuleName ChocolateyDSC

  #
  # Ensure all Features are installed
  as_pFeatures PSFeatures {
    Ensure    = $Ensure
    Features  = @("PowerShellRoot",
                  "PowerShell",
                  "PowerShell-V2",
                  "PowerShell-ISE")
  }


  # This doesn't work!
  # Set up a Chocalatey install path. If parameter is empty the default is used.
  Environment ChocolateyInstall {
    Name    = "ChocolateyInstall"
    Ensure  = $Ensure
    Value   = $ChocolateyPath
    Path    = $true
  }

  #
  # Variables for Chocolatey installation
  #$basePath          = "$env:Temp"
  $basePath          = "c:\work\orpheus"
  $chocolateyZip     = Join-Path  $basePath "chocolatey.zip"
  $chocolateyPackDir = Join-Path  $basePath "chocolateyPackDir"
  $chocolateyInstall = Join-Path  $chocolateyPackDir "tools\chocolateyInstall.ps1"

  # download package
  xRemoteFile chocolateyZip {
    DestinationPath = $chocolateyZip
    Uri             = "https://chocolatey.org/api/v2/package/chocolatey/"
    #Ensure          = "Present"
  }

  # unpack
  Archive chocolateyPackDir {
    Ensure      = $Ensure
    Destination = $chocolateyPackDir
    Path        = $chocolateyZip
    DependsOn   = "[xRemoteFile]chocolateyZip"
  }

  # install
  Script installChocolatey {
    SetScript =  {
      Import-Module OrpheusDSC
      $env:ChocolateyInstall = "$using:ChocolateyPath"
      $block = [string]"$using:chocolateyInstall"
      $result = ExecPowerShellScript $block -Verbose
      Write-Verbose $result
    }
    TestScript = {
        $chocolateyDir="$env:ChocolateyInstall"
        if ($chocolateyDir) {
            Test-Path "$env:ChocolateyInstall"
        } else {
            $false
        }
    }
    GetScript =  { <# This must return a hash table #> }
    dependsOn = @("[Archive]chocolateyPackDir", "[as_pFeatures]PSFeatures")
  }

  # Install WebPI
  cChocolateyPackage WebPI {
    PackageName = "webpicmd"
    Ensure = $Ensure
    #InstallOptions = "/quiet /qn /norestart"
  }

}
