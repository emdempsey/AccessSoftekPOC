Configuration as_rIIS {
<#
  .SYNOPSIS
  Install IIS and App Server (see spec. https://cf.mfmnow.com/display/Automation/Specifications+for+automation#Specificationsforautomation-IIS)

  .DESCRIPTION
  * Install:
    * .Net
    * Web Server
    * Activation services
    * WCF services
    * Application Services


  .PARAMETER Ensure
  Status: Absent or Ensure

  .NOTES
  (C) Access Softek 2015
  Maxim Nasonov, mnasonov@accesssoftek.com
  Ruslan Kalakutsky, rkalakutsky@accesssoftek.com

#>
  param (
      [parameter(Mandatory=$true)]
      [ValidateSet("Present","Absent")]
      [string] $Ensure
  )

  # Install .Net
  as_pFeatures DotNet {
    Ensure      = "$Ensure"
    Features    = @("NET-Framework-Features",
                    "NET-Framework-Core",
                    "NET-HTTP-Activation",
                    "NET-Non-HTTP-Activ",
                    "NET-Framework-45-Features",
                    "NET-Framework-45-Core",
                    "NET-Framework-45-ASPNET")
  }

  # Install WebServer
  as_pFeatures WebServer {
    Ensure      = "$Ensure"
    Features    = @("Web-Server",
                    "Web-WebServer",
                    "Web-Common-Http",
                    "Web-Default-Doc",
                    "Web-Dir-Browsing",
                    "Web-Http-Errors",
                    "Web-Static-Content",
                    "Web-Http-Redirect",
                    "Web-Health",
                    "Web-Http-Logging",
                    "Web-Custom-Logging",
                    "Web-Log-Libraries",
                    "Web-Request-Monitor",
                    "Web-Http-Tracing",
                    "Web-Performance",
                    "Web-Stat-Compression",
                    "Web-Dyn-Compression",
                    "Web-Security",
                    "Web-Filtering",
                    "Web-Basic-Auth",
                    "Web-CertProvider",
                    "Web-Client-Auth",
                    "Web-Digest-Auth",
                    "Web-Cert-Auth",
                    "Web-IP-Security",
                    "Web-Url-Auth",
                    "Web-Windows-Auth",
                    "Web-Mgmt-Tools",
                    "Web-Mgmt-Console",
                    "Web-Scripting-Tools")
    #DependsOn   = "[as_pFeatures]DotNet"
  }

  # Install Activation services
  as_pFeatures WAS {
    Ensure      = "$Ensure"
    #DependsOn   = "[as_pFeatures]DotNet"
    Features    = @("WAS",
                    "WAS-Process-Model",
                    "WAS-NET-Environment",
                    "WAS-Config-APIs")
  }

  # Install WCF Services
  as_pFeatures WCF {
    Ensure      = "$Ensure"
    #DependsOn   = "[as_pFeatures]WebServer"
    Features    = @("NET-WCF-Services45",
                    "NET-WCF-HTTP-Activation45",
                    "NET-WCF-Pipe-Activation45",
                    "NET-WCF-TCP-Activation45",
                    "NET-WCF-TCP-PortSharing45")
  }

  # Install Application Server
  as_pFeatures AppServer {
    Ensure      = "$Ensure"
    #DependsOn   = "[as_pFeatures]WCF"
    Features    = @("Application-Server",
                    "AS-NET-Framework",
                    "AS-Ent-Services",
                    "AS-TCP-Port-Sharing",
                    "AS-Web-Support",
                    "AS-WAS-Support",
                    "AS-HTTP-Activation",
                    "AS-Named-Pipes",
                    "AS-TCP-Activation")
  }

}
