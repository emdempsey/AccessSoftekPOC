Configuration as_rDevTools {
<#
  .SYNOPSIS
  Install Development Tools (see spec. https://cf.mfmnow.com/display/Automation/Specifications+for+automation#Specificationsforautomation-DevTools)

  .DESCRIPTION
  * Ensure Telnet client is installed
  * Install some tools like Far, Chrome, etc.

  .PARAMETER Ensure
  Status: Absent or Ensure

  .NOTES
  (C) Access Softek 2015
  Maxim Nasonov, mnasonov@accesssoftek.com
  Ruslan Kalakutsky, rkalakutsky@accesssoftek.com

#>
  param (
      [parameter(Mandatory=$true)]
      [ValidateSet("Present","Absent")]
      [string] $Ensure
  )

  # ChocolateyDSC
  Import-DscResource -ModuleName ChocolateyDSC

  #
  # Ensure TelnetClient Feature are installed
  WindowsFeature telnetClient {
    Ensure    = "Present"
    Name      = "Telnet-Client"
  }

  # Install Far
  cChocolateyPackage cFar {
    PackageName = "Far-3"
    Ensure = "Present"
  }

  # Install Chrome
  cChocolateyPackage cChrome {
    PackageName = "google-chrome-x64"
    Ensure = "Present"
  }

  # Install Notepad++
  cChocolateyPackage cNotepadPlusPlus {
    PackageName = "notepadplusplus"
    Ensure = "Present"
  }
}
