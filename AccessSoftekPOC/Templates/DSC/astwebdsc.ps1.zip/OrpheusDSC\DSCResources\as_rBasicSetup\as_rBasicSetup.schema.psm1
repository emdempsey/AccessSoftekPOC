Configuration as_rBasicSetup {
<#
  .SYNOPSIS
  https://cf.mfmnow.com/display/Automation/Specifications+for+automation

  .DESCRIPTION
  *

  .PARAMETER
  
  .PARAMETER

  .NOTES
  (C) Access Softek 2015
  Maxim Nasonov, mnasonov@accesssoftek.com
  Tetsuya Chiba, tchiba@accesssoftek.com
  Ruslan Kalakutsky, rkalakutsky@accesssoftek.com

#>
    param(
        
        [string] $ComputerName = "",

        [string[]] $DNSServers = "",

        [string] $Domain = "",

        [PSCredential] $DomainCredential,

        [string[]] $DisabledLocalUsers,

        [PSCredential[]] $LocalAdminCredentials,

        [bool] $InstallWindowsUpdates = $True,
      
        [bool] $InstallSystemSoftware = $True,
      
        [string] $NSclinetConfigFileContent,

        [bool] $InstallFirewallRules = $True
    )
    #
    Import-DscResource -ModuleName xNetworking

    #
    Import-DscResource -ModuleName xComputerManagement
  
    # xPackage
    Import-DscResource -ModuleName xPSDesiredStateConfiguration

    if ($DNSServers)
    {
        xDnsServerAddress OurDNS {
            Address = $DNSServers
            InterfaceAlias = Get-NetAdapter | ? { $_.Name -like '*Ethernet*' } | Select-Object -ExpandProperty Name -First 1
            AddressFamily = "IPv4"
        }
    }    

    if ($ComputerName)
    {
        if ($Domain -and (-Not ($DomainCredential)))
        {
            throw New-Object System.ArgumentException ("DomainCredential", "DomainCredential is empty")
        }

        xComputer OurDomainSettings {
            Name = $ComputerName
            DomainName = $Domain
            Credential = $DomainCredential
        }
    }

    Apply-LocalUserConfiguration -DisabledLocalUsers $DisabledLocalUsers -LocalAdminCredentials $LocalAdminCredentials
  
    if ($InstallWindowsUpdates)
    {
        pWindowsUpdates 'windowsUpdates-BasicSetup' {
            UniqKeyName = "BasicSetup"
            Ensure = "Present"
            #KBArticleID = @('KB2939087', 'KB2967917')
            KBArticleID = @()
            UpdateID = @()
        }
    }
  
    if ($InstallSystemSoftware)
    {
        Apply-SystemSoftwareConfiguration -NSclinetConfigFileContent $NSclinetConfigFileContent
    }

    if ($InstallFirewallRules)
    {
        Apply-FirewallConfiguration
    }
}

function Apply-LocalUserConfiguration
{
    param(
        [string[]] $DisabledLocalUsers,
        [PSCredential[]] $LocalAdminCredentials
    )

    $LocalAdministratorsGroupName = 'Administrators'
    $localUsers = Get-WmiObject -Class Win32_UserAccount | Select -expand Name

    if ($DisabledLocalUsers)
    {
        foreach ($user in $($DisabledLocalUsers | ? { $_ -in $localUsers })) {
            User "disable-${user}" {
                UserName = $user
                Disabled = $true
            }
        }
    }

    if ($LocalAdminCredentials)
    {
        $admins = @()
        foreach ($adminCred in $LocalAdminCredentials) 
        {
            $adminName = $adminCred.UserName
            $adminPass = $adminCred
    
            User "localAdminUser-$adminName" {
                UserName = $adminName
                Disabled = $false
                Ensure = 'Present'
                Password = $adminPass
                PasswordChangeNotAllowed = $false
                PasswordChangeRequired = $false
                PasswordNeverExpires = $true
            }
            $admins += $adminName
        }

        if ($admins) 
        {
            # NOTE: GroupName - is key, can not add some resource with same key value
            Group "localAdminUser-${adminName}" {
                GroupName = $LocalAdministratorsGroupName
                #Credential
                MembersToInclude = $admins
                DependsOn = $admins | % { "[User]localAdminUser-$_"}
            }
        }
    }
}

function Apply-SystemSoftwareConfiguration
{
    param(
        [string] $NSclinetConfigFileContent
    )

    xPackage 'SystemSoftware-Nagios' {
        Ensure = "Present"
        Name = "NSClient++ (x64)"
        # don`t find https url :(
        Path = "http://files.nsclient.org/released/NSCP-0.4.3.143-x64.msi"
        ProductId = ""
        Arguments = "/quiet /norestart ADDLOCAL=ALL"
    }
    
    if ($NSclinetConfigFileContent)
    {
        $destinationNsConfigPath = "C:\Program Files\NSClient++\nsclient.ini"
        Script 'SystemSoftware-Nagios-config' {
            GetScript  = { @{} }
            TestScript = {
                $testResult = [System.IO.File]::ReadAllText($using:destinationNsConfigPath) -eq $($using:NSclinetConfigFileContent)
                Write-Verbose $(if ($testResult) { "Content of nsclient config file is right" } else { "Content of nsclient config file is WRONG" })
                $testResult
            }
            SetScript  = {
                Write-Verbose "Set config file ('$using:destinationNsConfigPath') content"
                [System.IO.File]::WriteAllText($destinationNsConfigPath, $($using:NSclinetConfigFileContent))
                # NOTE: it is illegal
                #Set-Content -Path $destinationNsConfigPath -Value $($using:nsclinetConfigFileContent)
                Write-Verbose "Restarting nsclient service"
                Restart-Service -DisplayName "NSClient++ (x64)" -Force -Verbose
            }
            DependsOn = "[xPackage]SystemSoftware-Nagios"
        }
    }
    else
    {
        $message = "Please set NSclinetConfigFileContent param to configure Nagios Monitoring Client (NSClient++)."
        Write-Verbose $message
        Write-Warning $message
    }    
    
    # NOTE: can not find SplunkForward in free source. It needs register on site :(
    #xPackage 'SystemSoftware-Splunk' {
    #    Path = "http://www.splunk.com/en_us/download/universal-forwarder.html"
    #}
    
}

function Apply-FirewallConfiguration
{
    #Import-DscResource -ModuleName xNetworking
    $displayGroup = "Access Softek basic setup"

    # NOTE: this is disable because role 'Octopus Tentacle' add firewall rule self. See OctopusDSC module
    <#
    xFirewall FirewallConfigufation-Inbound {
        DisplayName = "Default DSC inbound rule"
        DisplayGroup = $displayGroup
        Ensure = "Present"
        Name = "DefaultDSCInbound"
        Direction = "Inbound"
        LocalPort = "10933" #Octopus Deploy Tentacle - 10933
        Protocol = "TCP"
        Access = "Allow"
    }
    #>

    xFirewall FirewallConfigufation-Outbound {
        DisplayName = "Default DSC outbound"
        DisplayGroup = $displayGroup
        Ensure = "Present"
        Name = "DefaultDSCOutbound"
        Direction = "Outbound"
        LocalPort = "443", "8200" #GotoMeeting - 443, 8200
        Protocol = "TCP"
        Access = "Allow"
    }
}

Export-ModuleMember -Function as_rBasicSetup