﻿Configuration Web {
        param 
	    ( 
	        [Parameter(Mandatory)]
	        [String]$DomainName,

            [Parameter(Mandatory)]
	        [String]$octRole,
            
            [Parameter(Mandatory)]
	        [String]$octEnv,

	        [Parameter(Mandatory)]
	        [System.Management.Automation.PSCredential]$Admincreds
	    )
		
        #AST modules resource
        Import-DscResource -ModuleName OrpheusDSC

        #cTentacleAgent
        Import-DscResource -ModuleName OctopusDSC
        
        Import-DscResource -ModuleName xComputerManagement, xComputerManagement, xNetworking

        #RackSpace Resource making Webpi easier
        Import-DscResource -ModuleName rsWPI
                                            
		[System.Management.Automation.PSCredential ]$pass = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

        Node Localhost {
           as_pFeatures DotNet {
                    Ensure      = 'Present'
                    Features    = @('NET-Framework-Features',
                        'NET-Framework-Core',
                        'NET-HTTP-Activation',
                        'NET-Non-HTTP-Activ',
                        'NET-Framework-45-Features',
                        'NET-Framework-45-Core',
                        'NET-Framework-45-ASPNET',
                        'PowerShellRoot',
                        'PowerShell',
                        'PowerShell-V2',
                        'PowerShell-ISE',
                        'Telnet-Client',
                        'DSC-Service',
                        'WoW64-Support')
            }
            as_pFeatures WebServer {
                    Ensure      = 'Present'
                    Features    = @('Web-Server',
                        'Web-WebServer',
                        'Web-Common-Http',
                        'Web-Default-Doc',
                        'Web-Dir-Browsing',
                        'Web-Http-Errors',
                        'Web-Static-Content',
                        'Web-Http-Redirect',
                        'Web-Health',
                        'Web-Http-Logging',
                        'Web-Custom-Logging',
                        'Web-Log-Libraries',
                        'Web-Request-Monitor',
                        'Web-Http-Tracing',
                        'Web-Performance',
                        'Web-Stat-Compression',
                        'Web-Dyn-Compression',
                        'Web-Security',
                        'Web-Filtering',
                        'Web-Basic-Auth',
                        'Web-CertProvider',
                        'Web-Client-Auth',
                        'Web-Digest-Auth',
                        'Web-Cert-Auth',
                        'Web-IP-Security',
                        'Web-Url-Auth',
                        'Web-Windows-Auth',
                        'Web-Mgmt-Tools',
                        'Web-Mgmt-Console',
                        'Web-Scripting-Tools')
                    DependsOn = '[as_pFeatures]DotNet'
            }
            #script block to download WebPI MSI from the Azure storage blob
            #Script DownloadWebPIImage
            #{
            #    GetScript = {
            #        @{
            #            Result = "WebPIInstall"
            #        }
            #    }
            #    TestScript = {
            #        Test-Path "C:\WindowsAzure\wpilauncher.exe"
            #    }
            #    SetScript ={
            #        $source = "http://go.microsoft.com/fwlink/?LinkId=255386"
            #        $destination = "C:\WindowsAzure\wpilauncher.exe"
            #        Invoke-WebRequest $source -OutFile $destination
            #    }
            #}
            #Package WebPi_Installation {
            #    Ensure = "Present"
            #    Name = "Microsoft Web Platform Installer 5.0"
            #    Path = "C:\WindowsAzure\wpilauncher.exe"
            #    ProductId = '4D84C195-86F0-4B34-8FDE-4A17EB41306A'
            #    Arguments = ''
            #}
            Package WebDeploy {
                Name = 'Microsoft Web Deploy 3.5'
                Path = 'http://download.microsoft.com/download/D/4/4/D446D154-2232-49A1-9D64-F5A9429913A4/WebDeploy_amd64_en-US.msi'
                ProductId = '1A81DA24-AF0B-4406-970E-54400D6EC118'
                Ensure = 'Present'
                DependsOn = '[as_pFeatures]WebServer'
            }
           #URLRewrite is installed with ARRv3
           #Package UrlRewrite {
           #     Ensure = 'Present'
           #     Name = 'IIS URL Rewrite Module 2'
           #     Path = 'http://download.microsoft.com/download/6/7/D/67D80164-7DD0-48AF-86E3-DE7A182D6815/rewrite_2.0_rtw_x64.msi'
           #     Arguments = '/quiet /norestart'
           #     ProductId = 'EB675D0A-2C95-405B-BEE8-B42A65D23E11'
           #     DependsOn = '[Package]WebDeploy'
           # }
           #Package ARR {
           #     Ensure = 'Present'
           #     Name = 'ARRv3_0'
           #     Path = 'C:\Program Files\Microsoft\Web Platform Installer\WebpiCmd.exe'
           #     ProductId = ''
           #     Arguments = '/Install /Products:ARRv3_0 /AcceptEULA'
           #     DependsOn = '[Package]WebPi_Installation'
           # }
           #Package Service_Bus_and_Azure_SDK {
           #     Ensure = 'Present'
           #     Name = 'Windows Azure Pack: Service Bus 1.1'
           #     Path = 'C:\Program Files\Microsoft\Web Platform Installer\WebpiCmd.exe'
           #     ProductId = ''
           #     Arguments = '/Install /Products:ServiceBus_1_1,VWDOrVs11AzurePack.2.5 /AcceptEULA'
           #     DependsOn = '[Package]WebPi_Installation'
           # }
            rsWPI ARR {
                 Product = "ARRv3_0"
            }
            rsWPI AzureSDK {
                 Product = "VWDOrVs11AzurePack.2.3"
            }
            rsWPI ServiceBus {
                 Product = "ServiceBus_1_1"
                 DependsOn = @("[rsWPI]AzureSDK")
            }
            #Package SSDT {
            #     Ensure    = 'Present'
            #     Name      = 'Microsoft SQL Server Data Tools 2012'
            #     Path = 'http://download.microsoft.com/download/4/9/0/4907755D-5E4A-4369-8E8D-E30FA7D22F22/EN/SSDTSetup.exe'
            #     ProductId = ''
            #     Arguments = '/norestart /q'
            #}
            #Package PowerShellSQLExtensions {
            #    Ensure = 'Present'
            #    Name = 'Windows PowerShell Extensions for SQL Server 2012 '
            #    Path = 'http://download.microsoft.com/download/F/E/D/FEDB200F-DE2A-46D8-B661-D019DFE9D470/ENU/x64/PowerShellTools.MSI'
            #    ProductId = ''
            #    Arguments = '/norestart IACCEPTSQLNCLILICENSETERMS=YES'
            #    DependsOn = '[Package]SSDT' # component "Microsoft SQL Server 2012 Management Objects"
            #}
            #Package SQLServerManagementObjects {
            #    Ensure = 'Present'
            #    Name = 'Microsoft SQL Server 2012 Management Objects  (x64)'
            #    Path = 'http://download.microsoft.com/download/F/E/D/FEDB200F-DE2A-46D8-B661-D019DFE9D470/ENU/x64/SharedManagementObjects.msi'
            #    ProductId = ''
            #    Arguments = '/norestart IACCEPTSQLNCLILICENSETERMS=YES'
            #    #DependsOn = "[Package]SQLSystemCRL"
            #    DependsOn = '[Package]SSDT' # component "SQL Server 2012 System CLR Types"
            #}
            #Package SQLNativeClient {
            #    Ensure = 'Present'
            #    Name = 'Microsoft SQL Server 2012 Native Client '
            #    Path = 'http://download.microsoft.com/download/F/E/D/FEDB200F-DE2A-46D8-B661-D019DFE9D470/ENU/x64/sqlncli.msi'
            #    ProductId = ''
            #    Arguments = '/norestart IACCEPTSQLNCLILICENSETERMS=YES'
            #    DependsOn = '[Package]PowerShellSQLExtensions'
            #}
            #Package SQLCmdLnUtils {
            #    Ensure = 'Present'
            #    Name = 'Microsoft SQL Server 2012 Command Line Utilities '
            #    Path = 'http://download.microsoft.com/download/F/E/D/FEDB200F-DE2A-46D8-B661-D019DFE9D470/ENU/x64/SqlCmdLnUtils.msi'
            #    ProductId = ''
            #    Arguments = '/norestart'
            #    DependsOn = '[Package]SQLNativeClient'
            #}
           #VCRed Missing
           #cTentacleAgent OctopusTentacle {
           #     Ensure = "Present";
           #     State  = "Started";             
           #     Name   = "Tentacle";
           #     ApiKey           = "API-GQNOB8UJDWA3V58ON9BGNEBZDYY";
           #     OctopusServerUrl = "https://deploy.orpheusdev.net";
           #     Environments     = @($octEnv);
           #     Roles            = @($octRole);
           #     ListenPort                  = "10933"
           #     DefaultApplicationDirectory = "c:\Applications"
           #}
            xDnsServerAddress DnsServerAddress {
                Address = '10.0.14.4', '10.0.14.5'
                AddressFamily = 'IPv4'
                InterfaceAlias = 'Ethernet'
            }
            xComputer JoinDomain {
                Name = $env:COMPUTERNAME
                DomainName = $DomainName
                Credential = $pass
                DependsOn = '[xDnsServerAddress]DnsServerAddress'
            }
      }
}