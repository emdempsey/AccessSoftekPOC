﻿Configuration AppO {
        #AST modules resource
        Import-DscResource -ModuleName OrpheusDSC
        #cTentacleAgent
        Import-DscResource -ModuleName OctopusDSC

        Import-DscResource -ModuleName xComputerManagement, xNetworking, cComputerManagement

        $DomainName = "devbeta.macuhosted"
        $UserName = "devbeta.macuhosted\addtodomain"
        $Password = "Office365" | ConvertTo-SecureString -asPlainText -Force #this is just for testing.
        $pass = New-Object System.Management.Automation.PSCredential ($UserName,$Password)

        Node Localhost {
           as_pFeatures EnFeature {
                Ensure = "Present"
                Features    = @("Telnet-Client",
                    "PowerShell",
                    "PowerShell-V2",
                    "DSC-Service",
                    "PowerShell-ISE",
                    "WoW64-Support")
           }
           as_pFeatures OrphApp {
                    Ensure      = "Present"
                    Features    = @("Web-Server",
                        "Web-Asp-Net45",
                        "Web-IP-Security",
                        "Web-Scripting-Tools",
                        "Telnet-Client",
                        "NET-Framework-45-ASPNET",
                        "AS-NET-Framework",
                        "NET-Framework-45-Features",
                        "Web-ASP",
                        "Web-ISAPI-Filter",
                        "MSMQ",
                        "MSMQ-Server",
                        "MSMQ-Directory",
                        "MSMQ-Triggers",
                        "MSMQ-Multicasting",
                        "MSMQ-Routing",
                        "MSMQ-DCOM")
           }
           Package WebDeploy {
                Name = "Microsoft Web Deploy 3.5"
                Path = "http://download.microsoft.com/download/D/4/4/D446D154-2232-49A1-9D64-F5A9429913A4/WebDeploy_amd64_en-US.msi"
                ProductId = "1A81DA24-AF0B-4406-970E-54400D6EC118"
                Ensure = "Present"
                DependsOn = "[as_pFeatures]WebServer"
            }
           Package Service_Bus_and_Azure_SDK {
                Ensure = "Present"
                Name = "Windows Azure Pack: Service Bus 1.1"
                Path = 'C:\Program Files\Microsoft\Web Platform Installer\WebpiCmd.exe'
                ProductId = ''
                Arguments = "/Install /Products:ServiceBus_1_1,VWDOrVs11AzurePack.2.3 /AcceptEULA"
                DependsOn = @("[Package]WebDeploy")
            }
           Package SSDT {
                Ensure    = "Present"
                Name      = "Microsoft SQL Server Data Tools 2012"
                Path = "http://download.microsoft.com/download/4/9/0/4907755D-5E4A-4369-8E8D-E30FA7D22F22/EN/SSDTSetup.exe"
                ProductId = ""
                Arguments = "/norestart /q"
            }
           Package PowerShellSQLExtensions {
                Ensure = "Present"
                Name = "Windows PowerShell Extensions for SQL Server 2012 "
                Path = "http://download.microsoft.com/download/F/E/D/FEDB200F-DE2A-46D8-B661-D019DFE9D470/ENU/x64/PowerShellTools.MSI"
                ProductId = ""
                Arguments = "/norestart IACCEPTSQLNCLILICENSETERMS=YES"
                DependsOn = "[Package]SSDT" # component "Microsoft SQL Server 2012 Management Objects"
            }
           Package SQLNativeClient {
                Ensure = "Present"
                Name = "Microsoft SQL Server 2012 Native Client "
                Path = "http://download.microsoft.com/download/F/E/D/FEDB200F-DE2A-46D8-B661-D019DFE9D470/ENU/x64/sqlncli.msi"
                ProductId = ""
                Arguments = "/norestart IACCEPTSQLNCLILICENSETERMS=YES"
                DependsOn = "[Package]PowerShellSQLExtensions"
            }
           Package SQLCmdLnUtils {
                Ensure = "Present"
                Name = "Microsoft SQL Server 2012 Command Line Utilities "
                Path = "http://download.microsoft.com/download/F/E/D/FEDB200F-DE2A-46D8-B661-D019DFE9D470/ENU/x64/SqlCmdLnUtils.msi"
                ProductId = ""
                Arguments = "/norestart"
                DependsOn = "[Package]SQLNativeClient"
            }
           #VCRed Missing
           cTentacleAgent OctopusTentacle {
                Ensure = "Present";
                State  = "Started";             
                Name   = "Tentacle";
                #ApiKey           = "API-000";
                #OctopusServerUrl = "https://deploy.orpheusdev.net";
                #Environments     = "test";
                #Roles            = "role";
                #ListenPort                  = "10933"
                DefaultApplicationDirectory = "$($env:SystemDrive)\Applications" # c:\Octopus;
            }
            cComputer JoinDomain {
                Name = $env:COMPUTERNAME
                DomainName = $DomainName
                Credential = $pass
           }
      }
}