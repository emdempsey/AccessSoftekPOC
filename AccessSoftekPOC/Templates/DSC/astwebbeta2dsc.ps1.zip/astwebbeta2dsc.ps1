﻿Configuration Web {
        param 
	    ( 
	        [Parameter(Mandatory)]
	        [String]$DomainName,

            [Parameter(Mandatory)]
	        [String]$octRole,
            
            [Parameter(Mandatory)]
	        [String]$octEnv,

	        [Parameter(Mandatory)]
	        [System.Management.Automation.PSCredential]$Admincreds
	    )
		
        #AST modules resource
        Import-DscResource -ModuleName OrpheusDSC

        #cTentacleAgent
        Import-DscResource -ModuleName OctopusDSC
        
        Import-DscResource -ModuleName xComputerManagement, cComputerManagement, xNetworking

        #RackSpace Resource making Webpi easier
        Import-DscResource -ModuleName rsWPI
                                            
		[System.Management.Automation.PSCredential ]$pass = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

        Node Localhost {
           as_pFeatures DotNet {
                    Ensure      = 'Present'
                    Features    = @('NET-Framework-Features',
                        'NET-Framework-Core',
                        'NET-HTTP-Activation',
                        'NET-Non-HTTP-Activ',
                        'NET-Framework-45-Features',
                        'NET-Framework-45-Core',
                        'NET-Framework-45-ASPNET',
                        'PowerShellRoot',
                        'PowerShell',
                        'PowerShell-V2',
                        'PowerShell-ISE',
                        'Telnet-Client',
                        'DSC-Service',
                        'WoW64-Support')
            }
            as_pFeatures WebServer {
                    Ensure      = 'Present'
                    Features    = @('Web-Server',
                        'Web-WebServer',
                        'Web-Common-Http',
                        'Web-Default-Doc',
                        'Web-Dir-Browsing',
                        'Web-Http-Errors',
                        'Web-Static-Content',
                        'Web-Http-Redirect',
                        'Web-Health',
                        'Web-Http-Logging',
                        'Web-Custom-Logging',
                        'Web-Log-Libraries',
                        'Web-Request-Monitor',
                        'Web-Http-Tracing',
                        'Web-Performance',
                        'Web-Stat-Compression',
                        'Web-Dyn-Compression',
                        'Web-Security',
                        'Web-Filtering',
                        'Web-Basic-Auth',
                        'Web-CertProvider',
                        'Web-Client-Auth',
                        'Web-Digest-Auth',
                        'Web-Cert-Auth',
                        'Web-IP-Security',
                        'Web-Url-Auth',
                        'Web-Windows-Auth',
                        'Web-Mgmt-Tools',
                        'Web-Mgmt-Console',
                        'Web-Scripting-Tools')
                    DependsOn = '[as_pFeatures]DotNet'
            }
            Package WebDeploy {
                Name = 'Microsoft Web Deploy 3.5'
                Path = 'http://download.microsoft.com/download/D/4/4/D446D154-2232-49A1-9D64-F5A9429913A4/WebDeploy_amd64_en-US.msi'
                ProductId = '1A81DA24-AF0B-4406-970E-54400D6EC118'
                Ensure = 'Present'
                DependsOn = '[as_pFeatures]WebServer'
            }
            rsWPI ARR {
                 Product = "ARRv3_0"
            }
            rsWPI AzureSDK {
                 Product = "VWDOrVs11AzurePack.2.3"
            }
            rsWPI ServiceBus {
                 Product = "ServiceBus_1_1"
                 DependsOn = @("[rsWPI]AzureSDK")
            }
           #cTentacleAgent OctopusTentacle {
           #     Ensure = "Present";
           #     State  = "Started";             
           #     Name   = "Tentacle";
           #     ApiKey           = "API-GQNOB8UJDWA3V58ON9BGNEBZDYY";
           #     OctopusServerUrl = "https://deploy.orpheusdev.net";
           #     Environments     = @($octEnv);
           #     Roles            = @($octRole);
           #     ListenPort                  = "10933"
           #     DefaultApplicationDirectory = "c:\Applications"
           #}
            xDnsServerAddress DnsServerAddress {
                Address = '10.0.14.4', '10.0.14.5'
                AddressFamily = 'IPv4'
                InterfaceAlias = 'Ethernet'
            }
            cComputer JoinDomain {
                Name = $env:COMPUTERNAME
                DomainName = $DomainName
                Credential = $pass
                DependsOn = '[xDnsServerAddress]DnsServerAddress'
            }
            LocalConfigurationManager {
                RebootNodeIfNeeded = $true
            }
      }
}