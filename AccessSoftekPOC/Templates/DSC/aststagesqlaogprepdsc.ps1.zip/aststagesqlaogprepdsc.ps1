configuration PrepareAlwaysOnSqlServer
{
    param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SQLServicecreds,

        [Parameter(Mandatory)]
        [String]$SqlAlwaysOnEndpointName,

        [UInt32]$DatabaseEnginePort = 1433,

        [String]$DomainNetbiosName=(Get-NetBIOSName -DomainName $DomainName),

        [Parameter(Mandatory)]
	    [String]$octRole,
            
        [Parameter(Mandatory)]
	    [String]$octEnv,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    )
    #AST modules resource
    Import-DscResource -ModuleName OrpheusDSC

    #cTentacleAgent
    Import-DscResource -ModuleName OctopusDSC

    Import-DscResource -ModuleName xComputerManagement, cDisk, xActiveDirectory, xDisk, xSql, xSQLServer, xSQLps, xNetworking
    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainNetbiosName}\$($Admincreds.UserName)", $Admincreds.Password)
    [System.Management.Automation.PSCredential]$DomainFQDNCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    [System.Management.Automation.PSCredential]$SQLCreds = New-Object System.Management.Automation.PSCredential ("${DomainNetbiosName}\$($SQLServicecreds.UserName)", $SQLServicecreds.Password)

    WaitForSqlSetup

    Node localhost
    {
        xWaitforDisk Disk2
        {
             DiskNumber = 2
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }

        cDiskNoRestart DataDisk
        {
            DiskNumber = 2
            DriveLetter = "F"
        }

        xWaitforDisk Disk3
        {
             DiskNumber = 3
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }

        cDiskNoRestart LogDisk
        {
            DiskNumber = 3
            DriveLetter = "G"
        }

        WindowsFeature FC
        {
            Name = "Failover-Clustering"
            Ensure = "Present"
        }

        WindowsFeature FCPS
        {
            Name = "RSAT-Clustering-PowerShell"
            Ensure = "Present"
        }

        WindowsFeature ADPS
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        }
        Script SQLStartupParam1 {
            GetScript  = { return @{}; }
            TestScript = {
                $startupParameter= "-T2371"
                $hklmRootNode = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server"
                $inst = "MSSQL12.MSSQLSERVER"
                $regKey = "$hklmRootNode\$inst\MSSQLServer\Parameters"
                $props = Get-ItemProperty $regKey
                $params = $props.psobject.properties | ?{$_.Name -like 'SQLArg*'} | select Name, Value
                foreach ($param in $params) {
                    if($param.Value -eq $StartupParameter) {
                        return $true
                    }
                }
                return $false
            }
            SetScript  = {
                $startupParameter= "-T2371"
                $hklmRootNode = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server"
                $inst = "MSSQL12.MSSQLSERVER"
                $regKey = "$hklmRootNode\$inst\MSSQLServer\Parameters"
                $props = Get-ItemProperty $regKey
                $params = $props.psobject.properties | ?{$_.Name -like 'SQLArg*'} | select Name, Value
                $newRegProp = "SQLArg"+($params.Count)
                Set-ItemProperty -Path $regKey -Name $newRegProp -Value $StartupParameter;
            }          
        }
        # Set SQL Trace Startup Parameter
        Script SQLStartupParam2 {
            GetScript  = { return @{}; }
            TestScript = {
                $startupParameter= "-T1118"
                $hklmRootNode = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server"
                $inst = "MSSQL12.MSSQLSERVER"
                $regKey = "$hklmRootNode\$inst\MSSQLServer\Parameters"
                $props = Get-ItemProperty $regKey
                $params = $props.psobject.properties | ?{$_.Name -like 'SQLArg*'} | select Name, Value
                foreach ($param in $params) {
                    if($param.Value -eq $StartupParameter) {
                        return $true
                    }
                }
                return $false
            }
            SetScript  = {
                $startupParameter= "-T1118"
                $hklmRootNode = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server"
                $inst = "MSSQL12.MSSQLSERVER"
                $regKey = "$hklmRootNode\$inst\MSSQLServer\Parameters"
                $props = Get-ItemProperty $regKey
                $params = $props.psobject.properties | ?{$_.Name -like 'SQLArg*'} | select Name, Value
                $newRegProp = "SQLArg"+($params.Count)
                Set-ItemProperty -Path $regKey -Name $newRegProp -Value $StartupParameter;
            }          
        }
        #Change SQL Login Mode
        Script SQLLoginMode {
            GetScript  = { return @{}; }
            TestScript = {
                import-module "sqlps" -DisableNameChecking
                $s = new-object ('Microsoft.SqlServer.Management.Smo.Server') $env:COMPUTERNAME
                [string]$nm = $s.Name
                [string]$mode = $s.Settings.LoginMode
                    if($mode.Value -ilike "Mixed") {
                        return $true
                    }
                return $false
            }
            SetScript  = {
                $s = new-object ('Microsoft.SqlServer.Management.Smo.Server') $env:COMPUTERNAME
                [string]$nm = $s.Name
                [string]$mode = $s.Settings.LoginMode

                $s.Settings.LoginMode = [Microsoft.SqlServer.Management.SMO.ServerLoginMode]::Mixed
                $s.Alter()
            }          
        }
        Script MSDBBrokerMode {
            GetScript  = { return @{}; }
            TestScript = {
                #$s = new-object ('Microsoft.SqlServer.Management.Smo.Server') $env:COMPUTERNAME
                $result = Invoke-Sqlcmd -Query "SELECT is_broker_enabled FROM sys.databases where Name = 'msdb';" -ServerInstance $env:COMPUTERNAME
                    if($result = 'True') {
                        return $true
                    }
                return $false
            }
            SetScript  = {
                #$s = new-object ('Microsoft.SqlServer.Management.Smo.Server') $env:COMPUTERNAME
                Invoke-Sqlcmd -Query "Alter Database msdb set enable_broker;" -ServerInstance $env:COMPUTERNAME
            }          
        }
        xSQLServerFirewall Setup-Firewall-SQL {
            Ensure = "Present"
		    SourcePath = "C:\SQLServer_12.0_Full"
		    SourceFolder = "\"
		    Features = "SQLENGINE,FULLTEXT,RS,SSMS,ADV_SSMS"
		    InstanceName = "MSSQLSERVER"
        }
        #pWindowsUpdates WindowsUpdates-BasicSetup {
        #    UniqKeyName = "SQLserver"
        #    Ensure = "Present"
        #    KBArticleID = @()
        #    UpdateID = @()
        #}
        xDnsServerAddress DnsServerAddress {
            Address = '10.0.14.4', '10.0.14.5'
            AddressFamily = 'IPv4'
            InterfaceAlias = 'Ethernet'
        }
        #xWaitForADDomain DscForestWait 
        #{ 
        #    DomainName = $DomainName 
        #    DomainUserCredential= $DomainCreds
        #    RetryCount = $RetryCount 
        #    RetryIntervalSec = $RetryIntervalSec 
        #}
        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
            DependsOn = "[xDnsServerAddress]DnsServerAddress"
        }
        xFirewall DatabaseEngineFirewallRule
        {
            Direction = "Inbound"
            Name = "SQL-Server-Database-Engine-TCP-In"
            DisplayName = "SQL Server Database Engine (TCP-In)"
            Description = "Inbound rule for SQL Server to allow TCP traffic for the Database Engine."
            DisplayGroup = "SQL Server"
            State = "Enabled"
            Access = "Allow"
            Protocol = "TCP"
            LocalPort = $DatabaseEnginePort -as [String]
            Ensure = "Present"
        }

        xFirewall DatabaseMirroringFirewallRule
        {
            Direction = "Inbound"
            Name = "SQL-Server-Database-Mirroring-TCP-In"
            DisplayName = "SQL Server Database Mirroring (TCP-In)"
            Description = "Inbound rule for SQL Server to allow TCP traffic for the Database Mirroring."
            DisplayGroup = "SQL Server"
            State = "Enabled"
            Access = "Allow"
            Protocol = "TCP"
            LocalPort = "5022"
            Ensure = "Present"
        }

        xFirewall ListenerFirewallRule
        {
            Direction = "Inbound"
            Name = "SQL-Server-Availability-Group-Listener-TCP-In"
            DisplayName = "SQL Server Availability Group Listener (TCP-In)"
            Description = "Inbound rule for SQL Server to allow TCP traffic for the Availability Group listener."
            DisplayGroup = "SQL Server"
            State = "Enabled"
            Access = "Allow"
            Protocol = "TCP"
            LocalPort = "59999"
            Ensure = "Present"
        }

        xSqlLogin AddDomainAdminAccountToSysadminServerRole
        {
            Name = $DomainCreds.UserName
            LoginType = "WindowsUser"
            ServerRoles = "sysadmin"
            Enabled = $true
            Credential = $Admincreds
        }

        xADUser CreateSqlServerServiceAccount
        {
            DomainAdministratorCredential = $DomainCreds
            DomainName = $DomainName
            UserName = $SQLServicecreds.UserName
            Password = $SQLServicecreds
            Ensure = "Present"
            DependsOn = "[xSqlLogin]AddDomainAdminAccountToSysadminServerRole"
        }

        xSqlLogin AddSqlServerServiceAccountToSysadminServerRole
        {
            Name = $SQLCreds.UserName
            LoginType = "WindowsUser"
            ServerRoles = "sysadmin"
            Enabled = $true
            Credential = $Admincreds
            DependsOn = "[xADUser]CreateSqlServerServiceAccount"
        }
        xSqlServer ConfigureSqlServerWithAlwaysOn
        {
            InstanceName = $env:COMPUTERNAME
            SqlAdministratorCredential = $Admincreds
            ServiceCredential = $SQLCreds
            MaxDegreeOfParallelism = 1
            FilePath = "F:\DATA"
            LogPath = "G:\LOG"
            DomainAdministratorCredential = $DomainFQDNCreds
            DependsOn = "[xSqlLogin]AddSqlServerServiceAccountToSysadminServerRole"
        }
        #cTentacleAgent OctopusTentacle {
           #     Ensure = "Present";
           #     State  = "Started";             
           #     Name   = "Tentacle";
           #     ApiKey           = "API-GQNOB8UJDWA3V58ON9BGNEBZDYY";
           #     OctopusServerUrl = "https://deploy.orpheusdev.net";
           #     Environments     = @($octEnv);
           #     Roles            = @($octRole);
           #     ListenPort                  = "10933"
           #     DefaultApplicationDirectory = "c:\Applications"
           #} 
        LocalConfigurationManager {
                RebootNodeIfNeeded = $true
        }

    }
}
function Get-NetBIOSName
{ 
    [OutputType([string])]
    param(
        [string]$DomainName
    )

    if ($DomainName.Contains('.')) {
        $length=$DomainName.IndexOf('.')
        if ( $length -ge 16) {
            $length=15
        }
        return $DomainName.Substring(0,$length)
    }
    else {
        if ($DomainName.Length -gt 15) {
            return $DomainName.Substring(0,15)
        }
        else {
            return $DomainName
        }
    }
}
function WaitForSqlSetup
{
    # Wait for SQL Server Setup to finish before proceeding.
    while ($true)
    {
        try
        {
            Get-ScheduledTaskInfo "\ConfigureSqlImageTasks\RunConfigureImage" -ErrorAction Stop
            Start-Sleep -Seconds 5
        }
        catch
        {
            break
        }
    }
}
