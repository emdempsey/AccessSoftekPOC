﻿Configuration Bast {
        param 
	    ( 
	        [Parameter(Mandatory)]
	        [String]$DomainName,

	        [Parameter(Mandatory)]
	        [System.Management.Automation.PSCredential]$Admincreds
	    )
		
        #AST modules resource
        Import-DscResource -ModuleName OrpheusDSC

        Import-DscResource -ModuleName xActiveDirectory, cComputerManagement, xNetworking
                    
		[System.Management.Automation.PSCredential ]$pass = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
        
        Node Localhost {
           as_pFeatures EnFeature {
                Ensure = "Present"
                Features    = @("Telnet-Client",
                    "PowerShell",
                    "PowerShell-V2",
                    "DSC-Service",
                    "PowerShell-ISE",
                    "WoW64-Support")
           }
           xDnsServerAddress DnsServerAddress {
                Address = '10.0.15.4', '10.0.15.5'
                AddressFamily = 'IPv4'
                InterfaceAlias = 'Ethernet'
           }
           cComputer JoinDomain {
                Name = $env:COMPUTERNAME
                DomainName = $DomainName
                Credential = $pass
                DependsOn = "[xDnsServerAddress]DnsServerAddress"
           }
           #LocalConfigurationManager {
           #     ActionAfterReboot = 'StopConfiguration'
           #}
        }
}