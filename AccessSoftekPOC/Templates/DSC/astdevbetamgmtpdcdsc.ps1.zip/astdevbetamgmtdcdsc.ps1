﻿
Configuration AD1 {
	param 
	   ( 
	        [Parameter(Mandatory)]
	        [String]$DomainName,

	        [Parameter(Mandatory)]
	        [System.Management.Automation.PSCredential]$Admincreds
	    )
		
        #AST modules resource
        Import-DscResource -ModuleName OrpheusDSC

        Import-DscResource -ModuleName xActiveDirectory
        
        #$DomainName = "devbeta.macuhosted"
        #$UserName = "nimda"
        #$Password = "Office365" | ConvertTo-SecureString -asPlainText -Force #this is just for testing.
        #$pass = New-Object System.Management.Automation.PSCredential ($UserName,$Password)
		[System.Management.Automation.PSCredential ]$pass = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
        
        Node Localhost {
           as_pFeatures EnFeature {
                Ensure = "Present"
                Features    = @("Telnet-Client",
                    "PowerShell",
                    "PowerShell-V2",
                    "DSC-Service",
                    "PowerShell-ISE",
                    "WoW64-Support")
           }
           User DomainAdmin {
                Ensure = "Present"
                UserName = "nimda"
                Password = $pass
            }
           as_pFeatures Features {
                Ensure = "Present"
                Features    = @("AD-Domain-Services",
                    "RSAT-AD-AdminCenter",
                    "RSAT-ADDS",
                    "RSAT-AD-PowerShell",
                    "RSAT-AD-Tools",
                    "RSAT-Role-Tools")
                    DependsOn = "[User]DomainAdmin"
            }
           xADDomain Domain {
                DomainName = $DomainName
                DomainAdministratorCredential = $pass
                SafemodeAdministratorPassword = $pass
                DependsOn = "[as_pFeatures]Features"
            }
           xWaitForADDomain DscForestWait { 
                DomainName = $DomainName
                DomainUserCredential = $pass
                RetryCount = 20
                RetryIntervalSec = 30
                DependsOn = "[xADDomain]Domain" 
            } 
          xADUser ASAdministrator {
               Ensure = "Present"
               DomainName = $DomainName
               UserName = "asadministrator"
               Password = $pass
               DomainAdministratorCredential = $pass
               DependsOn = "[xWaitForADDomain]DscForestWait"
           }
          xADUser addtodomain {
               Ensure = "Present"
               DomainName = $DomainName
               UserName = "addtodomain"
               Password = $pass
               DomainAdministratorCredential = $pass
               DependsOn = "[xWaitForADDomain]DscForestWait"
           }
           Script ASAdministratorToDomainAdmins {
                GetScript  = { return @{}; }
                TestScript = {
                    Get-ADGroupMember -Identity "Domain Admins" | % {
                        if ($_.SamAccountName -ilike "ASAdministrator") {
                            return $true
                        }
                    }
                    return $false
                }
                SetScript  = {
                    Add-ADGroupMember -Identity "Domain Admins" -Members "ASAdministrator";
                }          
                DependsOn = "[xADUser]ASAdministrator"
            }   
           Script addtodomainToDomainAdmins {
                GetScript  = { return @{}; }
                TestScript = {
                    Get-ADGroupMember -Identity "Domain Admins" | % {
                        if ($_.SamAccountName -ilike "addtodomain") {
                            return $true
                        }
                    }
                    return $false
                }
                SetScript  = {
                    Add-ADGroupMember -Identity "Domain Admins" -Members "addtodomain"
                }          
                DependsOn = "[xADUser]addtodomain"
            }   
        }
}
