﻿Configuration as_pFeatures {
<#
  .SYNOPSIS
  Install and deinstall Windows Roles and Features.

  .DESCRIPTION
  Composite DSC Resource for massive WindowsFeatures management.

  .PARAMETER Features
  List of Windows Features

  .PARAMETER Ensure
  Status of these features - Absent or Ensure

  .NOTES
  (C) Access Softek 2015
  Tetsuya Chiba, tchiba@accesssoftek.com
  Ruslan Kalakutsky, rkalakutsky@accesssoftek.com

#>
  param (
      [parameter(Mandatory=$true)]
      [ValidateNotNullOrEmpty()]
      [string[]] $Features,

      [parameter(Mandatory=$true)]
      [ValidateSet("Present","Absent")]
      [string] $Ensure
  )


  foreach ($feature in $Features) {
      WindowsFeature $feature {
          Name   = "$feature"
          Ensure = "$Ensure"
      }
  }
}
