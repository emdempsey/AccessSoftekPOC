﻿Configuration MFM {
        param 
	    ( 
	        [Parameter(Mandatory)]
	        [String]$DomainName,

            [Parameter(Mandatory)]
	        [String]$octRole,
            
            [Parameter(Mandatory)]
	        [String]$octEnv,

	        [Parameter(Mandatory)]
	        [System.Management.Automation.PSCredential]$Admincreds
	    )
		
        #AST modules resource
        Import-DscResource -ModuleName OrpheusDSC

        #cTentacleAgent
        Import-DscResource -ModuleName OctopusDSC
        
        Import-DscResource -ModuleName xComputerManagement, cComputerManagement, xSystemSecurity, xNetworking
                                    
		[System.Management.Automation.PSCredential ]$pass = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
        
        Node Localhost {
           as_pFeatures EnFeature {
                Ensure = "Present"
                Features    = @("PowerShell",
                    "PowerShell-V2",
                    "DSC-Service",
                    "PowerShell-ISE",
                    "WoW64-Support")
           }
           as_pFeatures MfmApp {
                    Ensure      = "Present"
                    Features    = @("Web-Server",
                        "Web-Asp-Net45",
                        "Web-IP-Security",
                        "Web-Scripting-Tools",
                        "Telnet-Client",
                        "NET-Framework-45-ASPNET",
                        "AS-NET-Framework",
                        "NET-Framework-45-Features",
                        "Web-ASP",
                        "Web-ISAPI-Filter",
                        "MSMQ",
                        "MSMQ-Server",
                        "MSMQ-Directory",
                        "MSMQ-Triggers",
                        "MSMQ-Multicasting",
                        "MSMQ-Routing",
                        "MSMQ-DCOM")
           }
           #cTentacleAgent OctopusTentacle {
           #     Ensure = "Present";
           #     State  = "Started";             
           #     Name   = "Tentacle";
           #     ApiKey           = "API-GQNOB8UJDWA3V58ON9BGNEBZDYY";
           #     OctopusServerUrl = "https://deploy.orpheusdev.net";
           #     Environments     = @($octEnv);
           #     Roles            = @($octRole);
           #     ListenPort                  = "10933"
           #     DefaultApplicationDirectory = "c:\Applications"
           #}
           xDnsServerAddress DnsServerAddress {
                Address = '10.0.14.4', '10.0.14.5'
                AddressFamily = 'IPv4'
                InterfaceAlias = 'Ethernet'
           }
           cComputer JoinDomain {
                Name = $env:COMPUTERNAME
                DomainName = $DomainName
                Credential = $pass
                DependsOn = "[xDnsServerAddress]DnsServerAddress"
           }
           LocalConfigurationManager {
                RebootNodeIfNeeded = $true
           }
      }
}