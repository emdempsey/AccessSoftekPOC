﻿Configuration AppM {
        #AST modules resource
        Import-DscResource -ModuleName OrpheusDSC
        #cTentacleAgent
        Import-DscResource -ModuleName OctopusDSC
        
        Import-DscResource -ModuleName xComputerManagement, xNetworking

        $DomainName = "devbeta.macuhosted"
        $UserName = "nimda"
        $Password = "Office365" | ConvertTo-SecureString -asPlainText -Force #this is just for testing.
        $pass = New-Object System.Management.Automation.PSCredential ($UserName,$Password)
        
        Node Localhost {
           as_pFeatures DisFeature {
                        Ensure      = "Absent"
                        Features    = @("AD-Certificate",
                                "AD-Domain-Services",
                                "ADFS-Federation",
                                "ADLDS",
                                "ADRMS",
                                "AS-Dist-Transaction",
                                "DHCP",
                                "DNS",
                                "Fax",
                                "FS-BranchCache",
                                "FS-Data-Deduplication",
                                "FS-DFS-Namespace",
                                "FS-DFS-Replication",
                                "FS-Resource-Manager",
                                "FS-VSS-Agent",
                                "FS-iSCSITarget-Server",
                                "iSCSITarget-VSS-VDS",
                                "FS-NFS-Service",
                                "FS-SyncShareService",
                                "Hyper-V",
                                "NPAS",
                                "Print-Services",
                                "RemoteAccess",
                                "Remote-Desktop-Services",
                                "VolumeActivation",
                                "Web-DAV-Publishing",
                                "Web-Ftp-Server",
                                "Web-Mgmt-Compat",
                                "Web-Mgmt-Service",
                                "WDS",
                                "ServerEssentialsRole",
                                "UpdateServices",
                                "BITS",
                                "BitLocker",
                                "BitLocker-NetworkUnlock",
                                "BranchCache",
                                "NFS-Client",
                                "Data-Center-Bridging",
                                "Direct-Play",
                                "EnhancedStorage",
                                "Failover-Clustering",
                                "GPMC",
                                "Web-WHC",
                                "Internet-Print-Client",
                                "IPAM",
                                "ISNS",
                                "LPR-Port-Monitor",
                                "Multipath-IO",
                                "NLB",
                                "PNRP",
                                "qWave",
                                "CMAK",
                                "Remote-Assistance",
                                "RDC",
                                "RPC-over-HTTP-Proxy",
                                "Simple-TCPIP",
                                "FS-SMBBW",
                                "SMTP-Server",
                                "SNMP-Service",
                                "Telnet-Server",
                                "TFTP-Client",
                                "Biometric-Framework",
                                "WFF",
                                "Windows-Identity-Foundation",
                                "Windows-Internal-Database",
                                "Search-Service",
                                "Windows-Server-Backup",
                                "Migration",
                                "WindowsStorageManagementService",
                                "Windows-TIFF-IFilter",
                                "WinRM-IIS-Ext",
                                "Wireless-Networking")
            }
           as_pFeatures EnFeature {
                Ensure = "Absent"
                Features    = @("Telnet-Client",
                    "PowerShell",
                    "PowerShell-V2",
                    "DSC-Service",
                    "PowerShell-ISE",
                    "WoW64-Support")
           }
           as_pFeatures MfmApp {
                    Ensure      = "Present"
                    Features    = @("Web-Server",
                        "Web-Asp-Net45",
                        "Web-IP-Security",
                        "Web-Scripting-Tools",
                        "Telnet-Client",
                        "NET-Framework-45-ASPNET",
                        "AS-NET-Framework",
                        "NET-Framework-45-Features",
                        "Web-ASP",
                        "Web-ISAPI-Filter",
                        "MSMQ",
                        "MSMQ-Server",
                        "MSMQ-Directory",
                        "MSMQ-Triggers",
                        "MSMQ-Multicasting",
                        "MSMQ-Routing",
                        "MSMQ-DCOM")
        }
           Package SSDT {
                Ensure    = "Present"
                Name      = "Microsoft SQL Server Data Tools 2012"
                Path = "http://download.microsoft.com/download/4/9/0/4907755D-5E4A-4369-8E8D-E30FA7D22F22/EN/SSDTSetup.exe"
                ProductId = ""
                Arguments = "/norestart /q"
            }
           Package PowerShellSQLExtensions {
                Ensure = "Present"
                Name = "Windows PowerShell Extensions for SQL Server 2012 "
                Path = "http://download.microsoft.com/download/F/E/D/FEDB200F-DE2A-46D8-B661-D019DFE9D470/ENU/x64/PowerShellTools.MSI"
                ProductId = ""
                Arguments = "/norestart IACCEPTSQLNCLILICENSETERMS=YES"
                DependsOn = "[Package]SSDT" # component "Microsoft SQL Server 2012 Management Objects"
            }
           cTentacleAgent OctopusTentacle {
                Ensure = "Present";
                State  = "Started";             
                Name   = "Tentacle";
                #ApiKey           = "API-000";
                #OctopusServerUrl = "https://deploy.orpheusdev.net";
                #Environments     = "test";
                #Roles            = "role";
                #ListenPort                  = "10933"
                DefaultApplicationDirectory = "$($env:SystemDrive)\Applications" # c:\Octopus;
            }
            xComputer JoinDomain {
                Name = $env:COMPUTERNAME
                DomainName = $DomainName
                Credential = $pass
           }
      }
}