﻿Configuration AD2 {
	param 
	   ( 
	        [Parameter(Mandatory)]
	        [String]$DomainName,

	        [Parameter(Mandatory)]
	        [System.Management.Automation.PSCredential]$Admincreds
	    )
		
        #AST modules resource
        Import-DscResource -ModuleName OrpheusDSC
        
        Import-DscResource -ModuleName xActiveDirectory, xNetworking
		
        #$DomainName = "devbeta.macuhosted"
        #$UserName = "nimda"
        #$Password = "Office365" | ConvertTo-SecureString -asPlainText -Force #this is just for testing.
        #$pass = New-Object System.Management.Automation.PSCredential ($UserName,$Password)
		[System.Management.Automation.PSCredential ]$pass = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
        
        Node Localhost {
           as_pFeatures EnFeature {
                Ensure = "Present"
                Features    = @("Telnet-Client",
                    "PowerShell",
                    "PowerShell-V2",
                    "DSC-Service",
                    "PowerShell-ISE",
                    "WoW64-Support",
                    "AD-Domain-Services")
           }
           User DomainAdmin {
                Ensure = "Present"
                UserName = "nimda"
                Password = $pass
            }
            ##This is just for testing before virtual network is created in customer subscription.
            #xDnsServerAddress DnsServerAddress {
            #    Address = '192.168.0.5', '8.8.8.8'
            #    AddressFamily = 'IPv4'
            #    InterfaceAlias = 'Ethernet'
            #}
           xWaitForADDomain DscForestWait { 
                DomainName = $DomainName
                DomainUserCredential = $pass
                RetryCount = 60
                RetryIntervalSec = 30
                DependsOn = "[as_pFeatures]EnFeature" #, "[xDNSServerAddress]DnsServerAddress" #remove dnsserver later
            } 
           xADDomainController SecondDC { 
                DomainName = $DomainName
                DomainAdministratorCredential = $pass
                SafemodeAdministratorPassword = $pass
                DependsOn = "[xWaitForADDomain]DscForestWait"
            }            
        }
}